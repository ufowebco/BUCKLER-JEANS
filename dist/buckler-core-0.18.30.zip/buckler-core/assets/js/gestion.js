/**
 * Gestión de tienda (/gestion-tienda/): resumen, pedidos, productos, carritos, correos, SEO y ADS (y ajustes).
 * JS propio sin dependencias. Datos por REST (bk/v1/gestion/*) con nonce wp_rest.
 * Velocidad: el resumen llega dentro de la página, las respuestas se guardan en memoria y se muestran al
 * instante mientras se actualizan por detrás, el detalle de un pedido se pide al pasar el cursor, y el
 * editor de productos y los módulos Carritos / Correos / SEO y ADS se cargan solo cuando se abren.
 */
(() => {
	'use strict';

	const C = window.bkG;
	const app = document.getElementById('bk-g-app');
	if (!C || !app) return;

	/* --- Utilidades ----------------------------------------------------------- */
	const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
	const $ = (sel, el = document) => el.querySelector(sel);
	const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
	const statusLabel = (s) => C.statuses[s] || s;
	const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== '' && v != null)).toString();

	const api = async (path, opts = {}) => {
		const res = await fetch(C.api + path, {
			method: opts.method || 'GET',
			credentials: 'same-origin',
			cache: 'no-store', // Siempre datos nuevos (pedidos recién llegados).
			headers: { 'X-WP-Nonce': C.nonce, 'Content-Type': 'application/json', Accept: 'application/json' },
			body: opts.body ? JSON.stringify(opts.body) : undefined,
		});
		const data = await res.json().catch(() => ({}));
		if (!res.ok) throw Object.assign(new Error(data.message || 'No se pudo completar la acción.'), { field: data.data?.field });
		return data;
	};

	// Caché en memoria: muestra lo último que se vio y lo actualiza por detrás (stale-while-revalidate).
	const memo = new Map();
	const inflight = new Map();
	const getCached = (path) => memo.get(path);
	const fetchFresh = (path) => {
		if (inflight.has(path)) return inflight.get(path);
		const pr = api(path).then((d) => { memo.set(path, d); return d; }).finally(() => inflight.delete(path));
		inflight.set(path, pr);
		return pr;
	};
	const forget = (prefix) => { [...memo.keys()].forEach((k) => { if (k.startsWith(prefix)) memo.delete(k); }); };
	if (C.boot?.summary) memo.set('summary', C.boot.summary);

	// Carga diferida de los demás archivos JS del panel.
	const scripts = {};
	const loadScript = (name) => scripts[name] || (scripts[name] = new Promise((ok, fail) => {
		const el = document.createElement('script');
		el.src = C.js[name];
		el.onload = ok;
		el.onerror = () => { delete scripts[name]; fail(new Error('No se pudo cargar esta sección. Revisa tu conexión.')); };
		document.head.appendChild(el);
	}));

	let toastTimer = 0;
	const toast = (msg, type = 'ok') => {
		const t = $('#bk-g-toast');
		t.textContent = msg;
		t.className = `bk-g-toast is-${type} is-on`;
		clearTimeout(toastTimer);
		toastTimer = setTimeout(() => t.classList.remove('is-on'), 3500);
	};

	// Evita dobles clics mientras se guarda.
	const busy = async (btn, fn) => {
		if (btn?.disabled) return;
		if (btn) { btn.disabled = true; btn.setAttribute('aria-busy', 'true'); }
		try { return await fn(); } catch (e) { toast(e.message, 'err'); } finally {
			if (btn) { btn.disabled = false; btn.removeAttribute('aria-busy'); }
		}
	};

	/* --- Estructura ------------------------------------------------------------- */
	// Usuarios de solo SEO y ADS (p. ej. Gestor_ADS): ese módulo y la ayuda.
	const tabs = C.scope === 'seo' ? [
		['seo', 'SEO y ADS', 'chart'],
		['ayuda', 'Ayuda', 'help'],
	] : [
		['resumen', 'Resumen', 'home'],
		['pedidos', 'Pedidos', 'orders'],
		['productos', 'Productos', 'prod'],
		['descuentos', 'Descuentos', 'percent'],
		['carritos', 'Carritos', 'cart'],
		['correos', 'Correos', 'mail'],
		['contenido', 'Contenido', 'layout'],
		['seo', 'SEO y ADS', 'chart'],
		['ayuda', 'Ayuda', 'help'],
	];
	// Ajustes ya no va en el menú (los campos reales quedaron por defecto): sigue en #ajustes para administradores.
	const hidden = C.isAdmin && C.scope !== 'seo' ? ['ajustes'] : [];
	const home = tabs[0][0];
	app.innerHTML = `
		<header class="bk-g-top">
			<a class="bk-g-brand" href="#${home}"><strong>Buckler</strong> <span>Gestión de tienda</span></a>
			<nav class="bk-g-tabs" aria-label="Secciones">${tabs.map(([k, l, i]) => `<a href="#${k}" data-tab="${k}">${C.icons[i] || ''}<span>${l}</span></a>`).join('')}</nav>
			<div class="bk-g-user"><a href="${esc(C.site)}" target="_blank" rel="noopener">Ver tienda</a><span>${esc(C.user)}</span><a href="${esc(C.logout)}">Salir</a></div>
		</header>
		<main id="bk-g-main" class="bk-g-main" tabindex="-1"></main>
		<div id="bk-g-drawer" class="bk-g-drawer" hidden>
			<div class="bk-g-drawer__scrim" data-close></div>
			<section class="bk-g-drawer__panel" role="dialog" aria-modal="true" aria-labelledby="bk-g-dtitle"></section>
		</div>
		<div id="bk-g-preview" class="bk-g-preview" hidden>
			<div class="bk-g-preview__box" role="dialog" aria-modal="true" aria-labelledby="bk-g-ptitle"></div>
		</div>
		<div id="bk-g-toast" class="bk-g-toast" role="status" aria-live="polite"></div>
		${C.isAdmin ? '<footer class="bk-g-foot"><a href="#ajustes">Ajustes avanzados de campos</a></footer>' : ''}`;
	const main = $('#bk-g-main');

	/* --- Router por hash ---------------------------------------------------------- */
	// Cada vista/consulta lleva un número: si llega una respuesta vieja (otra pestaña u otra búsqueda), se descarta.
	let viewSeq = 0;
	let oSeq = 0;
	let pSeq = 0;
	const route = () => {
		viewSeq++;
		const [path, query = ''] = (location.hash.replace('#', '') || home).split('?');
		const [tab, ...sub] = path.split('/');
		const valid = tabs.some(([k]) => k === tab) || hidden.includes(tab) ? tab : home;
		$$('.bk-g-tabs a').forEach((a) => a.toggleAttribute('aria-current', a.dataset.tab === valid));
		// Subrutas de productos (#productos/nuevo, #productos/editar/ID): gestion-product.js (se carga al usarlo).
		if (valid === 'productos' && sub.length) {
			const seq = viewSeq;
			if (!window.bkGProduct) main.innerHTML = '<div class="bk-g-loading">Cargando…</div>';
			loadScript('product').then(() => { if (seq === viewSeq) window.bkGProduct.view(sub, new URLSearchParams(query)); }).catch((e) => { main.innerHTML = `<p class="bk-g-error">${esc(e.message)}</p>`; });
			return;
		}
		// Pedido manual (#pedidos/nuevo): gestion-manual.js.
		if (valid === 'pedidos' && sub[0] === 'nuevo') {
			const seq = viewSeq;
			if (!window.bkGManual) main.innerHTML = '<div class="bk-g-loading">Cargando…</div>';
			loadScript('manual').then(() => { if (seq === viewSeq) window.bkGManual.view(); }).catch((e) => { main.innerHTML = `<p class="bk-g-error">${esc(e.message)}</p>`; });
			return;
		}
		// Descuentos, Contenido y Ayuda: gestion-more.js.
		if (['descuentos', 'contenido', 'ayuda'].includes(valid)) {
			const seq = viewSeq;
			if (!window.bkGMore) main.innerHTML = '<div class="bk-g-loading">Cargando…</div>';
			loadScript('more').then(() => { if (seq === viewSeq) window.bkGMore.view(valid, sub, new URLSearchParams(query)); }).catch((e) => { main.innerHTML = `<p class="bk-g-error">${esc(e.message)}</p>`; });
			return;
		}
		// Carritos, Correos y SEO y ADS: gestion-extra.js.
		if (['carritos', 'correos', 'seo'].includes(valid)) {
			const seq = viewSeq;
			if (!window.bkGExtra) main.innerHTML = '<div class="bk-g-loading">Cargando…</div>';
			loadScript('extra').then(() => { if (seq === viewSeq) window.bkGExtra.view(valid, sub, new URLSearchParams(query)); }).catch((e) => { main.innerHTML = `<p class="bk-g-error">${esc(e.message)}</p>`; });
			return;
		}
		({ resumen: viewSummary, pedidos: viewOrders, productos: viewProducts, ajustes: viewSettings })[valid]();
	};
	window.addEventListener('hashchange', route);

	/* --- Resumen ------------------------------------------------------------------- */
	const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

	// Meta diaria de ventas (pedidos pagados): hoy frente a la meta + los últimos 10 días, con mensajes de ánimo.
	const DAYS = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
	const dayLabel = (iso, today) => {
		if (iso === today) return 'Hoy';
		const dt = new Date(`${iso}T12:00:00`);
		return `${DAYS[dt.getDay()]} ${dt.getDate()}`;
	};
	// En la gráfica: día de la semana y número en dos piezas (en el celular van una debajo de la otra).
	const dayHtml = (iso, today) => {
		const [a, n] = dayLabel(iso, today).split(' ');
		return n ? `<span>${esc(a)}</span> ${esc(n)}` : esc(a);
	};
	const goalMessage = (n, goal) => {
		const left = goal - n;
		if (n >= goal * 1.5) return `¡Día récord! Van ${n} ventas, ${n - goal} por encima de la meta. 🚀`;
		if (n > goal) return `¡Meta superada! ${n} ventas hoy, ${n - goal} más de lo planeado. 🎉`;
		if (n === goal) return `¡Meta cumplida! ${goal} de ${goal}… y el día sigue. 🎉`;
		if (n === 0) return `¡Arranquemos! La primera de las ${goal} ventas de hoy está por llegar.`;
		if (n >= goal * 0.75) return `¡Casi! Solo ${plural(left, 'venta', 'ventas')} para la meta. 💪`;
		if (n >= goal * 0.5) return `¡Más de la mitad! Faltan ${plural(left, 'venta', 'ventas')}.`;
		return `Vamos en camino: ${plural(n, 'venta', 'ventas')}, faltan ${left} para la meta.`;
	};
	function goalCard(g) {
		const goal = Math.max(1, Number(g.goal) || 15);
		const days = g.days || [];
		const today = days.find((x) => x.date === g.today) || { count: 0, total: '' };
		const past = days.filter((x) => x.date !== g.today);
		const pct = Math.min(100, Math.round((today.count / goal) * 100));
		const met = past.filter((x) => x.count >= goal).length;
		const avg = past.length ? past.reduce((a, x) => a + x.count, 0) / past.length : 0;
		const best = days.reduce((a, x) => (x.count > a.count ? x : a), { count: -1 });
		// Racha: días seguidos con la meta cumplida, contando hacia atrás desde ayer (y hoy si ya se cumplió).
		let streak = today.count >= goal ? 1 : 0;
		for (let i = past.length - 1; i >= 0 && past[i].count >= goal; i--) streak++;
		const max = Math.max(goal, ...days.map((x) => x.count)) * 1.15;
		const goalPos = goal / max;
		return `<section class="bk-g-card bk-g-goal${today.count >= goal ? ' is-met' : ''}" aria-labelledby="bk-g-goal-h">
			<div class="bk-g-goal__head">
				<h2 id="bk-g-goal-h">Meta del día <small>(${plural(goal, 'venta', 'ventas')} pagadas)</small></h2>
				<button type="button" class="bk-g-link" data-goal-edit aria-expanded="false" aria-controls="bk-g-goal-form">Cambiar meta</button>
			</div>
			<form id="bk-g-goal-form" class="bk-g-goal__form" data-goal-form novalidate hidden>
				<label for="bk-g-goal-n">Ventas pagadas al día</label>
				<input id="bk-g-goal-n" type="number" min="1" max="1000" step="1" inputmode="numeric" value="${goal}" required>
				<button type="submit" class="bk-g-btn">Guardar meta</button>
				<p class="bk-g-goal__err" role="alert"></p>
			</form>
			<div class="bk-g-goal__today">
				<div class="bk-g-goal__ring" style="--p:${pct}" role="img" aria-label="Hoy: ${today.count} de ${goal} ventas (${pct} %)">
					<b>${today.count}</b><span>de ${goal}</span>
				</div>
				<div class="bk-g-goal__msg">
					<p class="bk-g-goal__big">${esc(goalMessage(today.count, goal))}</p>
					<div class="bk-g-goal__bar" aria-hidden="true"><i style="--w:${pct}%"></i></div>
					<p class="bk-g-hint">${today.total ? `Hoy: ${esc(today.total)}. ` : ''}${today.count < goal ? `Para llegar faltan <b>${goal - today.count}</b>.` : 'Todo lo que entre hoy suma al récord.'}</p>
				</div>
			</div>
			<div class="bk-g-goal__subrow">
				<h3 class="bk-g-goal__sub">Últimos ${days.length} días</h3>
				<ul class="bk-g-goal__legend" aria-hidden="true"><li class="is-line">Meta ${goal}</li><li class="is-met">Meta cumplida</li><li class="is-today">Hoy</li></ul>
			</div>
			<div class="bk-g-goal__plot" style="--goal:${goalPos.toFixed(3)}"><ol class="bk-g-goal__chart" aria-label="Ventas por día frente a la meta de ${goal}">
				${days.map((x) => `<li class="${x.count >= goal ? 'is-met' : ''}${x.date === g.today ? ' is-today' : ''}">
					<span class="bk-g-goal__col" style="--h:${((x.count / max) * 100).toFixed(1)}%"><i></i><b>${x.count}</b></span>
					<span class="bk-g-goal__day" aria-hidden="true">${dayHtml(x.date, g.today)}</span>
					<span class="bk-g-sr">${esc(dayLabel(x.date, g.today))}: ${plural(x.count, 'venta', 'ventas')}${x.count >= goal ? ', meta cumplida' : `, faltaron ${goal - x.count}`}</span>
				</li>`).join('')}
			</ol><span class="bk-g-goal__line" aria-hidden="true"></span></div>
			<ul class="bk-g-goal__stats">
				<li><b>${met} de ${past.length}</b><span>días con la meta cumplida</span></li>
				<li><b>${avg.toLocaleString('es-CO', { maximumFractionDigits: 1 })}</b><span>ventas al día en promedio</span></li>
				<li><b>${streak ? plural(streak, 'día', 'días') : '—'}</b><span>${streak ? 'seguidos cumpliendo la meta' : 'racha: cumple la meta hoy para empezar una'}</span></li>
				<li><b>${best.count > 0 ? best.count : '—'}</b><span>${best.count > 0 ? `mejor día (${esc(dayLabel(best.date, g.today))})` : 'mejor día'}</span></li>
			</ul>
		</section>`;
	}

	// Cambiar la meta: formulario en línea dentro de la tarjeta.
	document.addEventListener('click', (e) => {
		const b = e.target.closest('[data-goal-edit]');
		if (!b) return;
		const f = document.querySelector('[data-goal-form]');
		if (!f) return;
		f.hidden = !f.hidden;
		b.setAttribute('aria-expanded', String(!f.hidden));
		if (!f.hidden) f.querySelector('input').focus();
	});
	document.addEventListener('submit', async (e) => {
		const f = e.target.closest('[data-goal-form]');
		if (!f) return;
		e.preventDefault();
		const n = parseInt(f.querySelector('input').value, 10);
		const err = f.querySelector('.bk-g-goal__err');
		if (!(n >= 1 && n <= 1000)) { err.textContent = 'Escribe un número entre 1 y 1000.'; return; }
		const btn = f.querySelector('button');
		btn.disabled = true;
		try {
			await api('goal', { method: 'POST', body: { goal: n } });
			forget('summary');
			viewSummary();
		} catch (x) { err.textContent = x.message; btn.disabled = false; }
	});

	async function viewSummary() {
		const seq = viewSeq;
		const paint = (d) => {
			if (seq !== viewSeq) return;
			main.innerHTML = `<h1 class="bk-g-h1">Resumen</h1>
				<div class="bk-g-kpis">
					<div class="bk-g-kpi"><span>Ventas de hoy</span><b>${esc(d.today.total)}</b><small>${plural(d.today.count, 'pedido pagado', 'pedidos pagados')}</small></div>
					<div class="bk-g-kpi"><span>Ventas del mes</span><b>${esc(d.month.total)}</b><small>${plural(d.month.count, 'pedido pagado', 'pedidos pagados')}</small></div>
					<a class="bk-g-kpi is-link" href="#pedidos?status=processing"><span>Por despachar</span><b>${d.pending.processing}</b><small>En proceso</small></a>
					<a class="bk-g-kpi is-link" href="#pedidos?status=on-hold"><span>En espera</span><b>${d.pending['on-hold']}</b><small>Revisar pago</small></a>
					<a class="bk-g-kpi is-link" href="#pedidos?status=pending"><span>Pendientes de pago</span><b>${d.pending.pending}</b><small>Sin pagar aún</small></a>
				</div>
				${d.goal ? goalCard(d.goal) : ''}
				${d.sources?.length ? `<section class="bk-g-card"><h2>¿De dónde vienen las ventas? <small>(este mes, pedidos pagados)</small></h2>
					<ul class="bk-g-srcs">${d.sources.map((x) => `<li><a href="#pedidos?source=${esc(x.key)}">${srcChip({ key: x.key, label: x.label })}<span class="bk-g-srcs__bar"><i style="--w:${Math.max(2, x.pct)}%"></i></span><b>${esc(x.total)}</b><small>${x.count} pedido${x.count === 1 ? '' : 's'} · ${x.pct} %</small></a></li>`).join('')}</ul>
					<p class="bk-g-hint">Se toma de lo que WooCommerce registra en cada compra (enlace de la campaña, buscador, red social o sitio de donde llegó la clienta). "Sin dato": pedidos de antes de activar el registro o con bloqueadores de anuncios.</p></section>` : ''}
				<section class="bk-g-card"><h2>Tallas por agotarse (1–2 unidades)</h2>
				${d.low.length ? `<div class="bk-g-table-wrap"><table class="bk-g-table"><thead><tr><th>Producto</th><th>REF</th><th>Talla</th><th>Quedan</th></tr></thead><tbody>
					${d.low.map((l) => `<tr><td>${esc(l.name)}</td><td>${esc(l.sku)}</td><td>${esc(l.size)}</td><td><b class="bk-g-low">${l.stock}</b></td></tr>`).join('')}
				</tbody></table></div>` : '<p class="bk-g-empty">No hay tallas con stock bajo.</p>'}</section>`;
		};
		const old = getCached('summary');
		if (old) paint(old); else main.innerHTML = '<h1 class="bk-g-h1">Resumen</h1><div class="bk-g-loading">Cargando…</div>';
		try {
			const d = await fetchFresh('summary');
			if (JSON.stringify(d) !== JSON.stringify(old)) paint(d);
		} catch (e) { if (!old) main.innerHTML = `<p class="bk-g-error">${esc(e.message)}</p>`; }
		// Mientras se mira el resumen, se deja lista la primera página de pedidos.
		if (!getCached(`orders?${qs(oState)}`)) setTimeout(() => fetchFresh(`orders?${qs(oState)}`).catch(() => {}), 300);
	}

	/* --- Pedidos ------------------------------------------------------------------- */
	const hashParams = () => new URLSearchParams(location.hash.split('?')[1] || '');
	const oState = { q: '', status: 'all', paid_ok: '', printed: '', dispatched: '', source: '', from: '', to: '', page: 1 };
	// Origen de la venta: etiqueta con ícono (Meta Ads, Google orgánico, WhatsApp…).
	const srcChip = (s, withDetail) => s && C.sources?.[s.key] ? `<span class="bk-g-src is-${esc(s.key)}" title="${esc(s.detail || s.label)}">${C.sources[s.key].icon}${esc(s.label)}</span>${withDetail && s.detail ? ` <small class="bk-g-src__d">${esc(s.detail)}</small>` : ''}` : '';

	async function viewOrders() {
		const hp = hashParams();
		if (hp.get('status')) oState.status = hp.get('status');
		if (hp.has('source')) { oState.source = hp.get('source'); oState.page = 1; }
		main.innerHTML = `<div class="bk-g-h1row"><h1 class="bk-g-h1">Pedidos</h1>
				<div class="bk-g-refresh"><small id="bk-g-oupd" aria-live="polite"></small><button type="button" class="bk-g-btn" data-orders-refresh>${C.icons.refresh || ''} Buscar pedidos nuevos</button><a class="bk-g-btn" href="#pedidos/nuevo">${C.icons.plus} Nuevo pedido</a></div></div>
			<form class="bk-g-filters" id="bk-g-of" role="search">
				<label class="bk-g-search"><span class="bk-g-sr">Buscar pedidos</span>${C.icons.search}
					<input type="search" name="q" value="${esc(oState.q)}" placeholder="Número, consecutivo, cédula, nombre, correo o celular" autocomplete="off"></label>
				<label><span>Estado</span><select name="status"><option value="all">Todos</option>${Object.entries(C.statuses).map(([k, v]) => `<option value="${k}" ${oState.status === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
				<label><span>Pago</span><select name="paid_ok"><option value="">Todos</option><option value="no" ${oState.paid_ok === 'no' ? 'selected' : ''}>Sin confirmar</option><option value="yes" ${oState.paid_ok === 'yes' ? 'selected' : ''}>Confirmado</option></select></label>
				<label><span>Origen</span><select name="source"><option value="">Todos</option>${Object.entries(C.sources || {}).map(([k, v]) => `<option value="${k}" ${oState.source === k ? 'selected' : ''}>${esc(v.label)}</option>`).join('')}</select></label>
				<label><span>Impresión</span><select name="printed"><option value="">Todos</option><option value="no" ${oState.printed === 'no' ? 'selected' : ''}>Sin imprimir</option><option value="yes" ${oState.printed === 'yes' ? 'selected' : ''}>Impresos</option></select></label>
				${C.hasDispatch ? `<label><span>Despacho</span><select name="dispatched"><option value="">Todos</option><option value="no" ${oState.dispatched === 'no' ? 'selected' : ''}>Sin despachar</option><option value="yes" ${oState.dispatched === 'yes' ? 'selected' : ''}>Despachados</option></select></label>` : ''}
				<label><span>Desde</span><input type="date" name="from" value="${esc(oState.from)}"></label>
				<label><span>Hasta</span><input type="date" name="to" value="${esc(oState.to)}"></label>
				<button type="submit" class="bk-g-btn">Buscar</button>
			</form>
			<div id="bk-g-olist" aria-live="polite"></div>`;
		const form = $('#bk-g-of');
		let t = 0;
		form.addEventListener('submit', (e) => { e.preventDefault(); readForm(form); loadOrders(); });
		form.addEventListener('change', (e) => { if (e.target.name !== 'q') { readForm(form); loadOrders(); } });
		form.q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { readForm(form); loadOrders(); }, 450); });
		loadOrders();
	}
	const readForm = (form) => {
		Object.assign(oState, Object.fromEntries(new FormData(form).entries()), { page: 1 });
	};

	async function loadOrders() {
		const box = $('#bk-g-olist');
		if (!box) return;
		const seq = ++oSeq;
		const path = `orders?${qs(oState)}`;
		const old = getCached(path);
		if (old) paintOrders(box, old); else box.innerHTML = '<div class="bk-g-loading">Cargando pedidos…</div>';
		try {
			const d = await fetchFresh(path);
			if (seq !== oSeq || !box.isConnected) return;
			if (JSON.stringify(d) !== JSON.stringify(old)) paintOrders(box, d);
			markUpdated();
			return d;
		} catch (e) { if (!old) box.innerHTML = `<p class="bk-g-error">${esc(e.message)}</p>`; }
		return null;
	}

	/* --- Pedidos nuevos: botón y revisión automática cada 10 minutos ------------------------------- */
	const REFRESH_MS = 10 * 60 * 1000;
	let lastRefresh = Date.now();
	const seenIds = new Set();
	const hhmm = () => new Date().toLocaleTimeString('es-CO', { hour: 'numeric', minute: '2-digit' });
	const markUpdated = () => { const el = $('#bk-g-oupd'); if (el) el.textContent = `Actualizado ${hhmm()}`; };
	const rememberIds = (d) => (d?.orders || []).forEach((o) => seenIds.add(o.id));

	async function refreshOrders(manual) {
		lastRefresh = Date.now();
		forget('orders?');
		forget('summary');
		if (!$('#bk-g-olist')) {
			if (/^#?(resumen)?$/.test(location.hash.split('?')[0])) viewSummary(); // En otras secciones solo se vacía la caché.
			return;
		}
		const before = new Set(seenIds);
		const d = await loadOrders();
		if (!d) return;
		const fresh = (d.orders || []).filter((o) => before.size && !before.has(o.id));
		rememberIds(d);
		fresh.forEach((o) => $(`[data-row="${o.id}"]`)?.classList.add('is-new'));
		if (fresh.length) toast(fresh.length === 1 ? '1 pedido nuevo' : `${fresh.length} pedidos nuevos`);
		else if (manual) toast('No hay pedidos nuevos');
	}
	setInterval(() => { if (document.visibilityState === 'visible') refreshOrders(false).catch(() => {}); }, REFRESH_MS);
	// Si la pestaña estuvo oculta más de 10 minutos, revisa apenas vuelve.
	document.addEventListener('visibilitychange', () => {
		if (document.visibilityState === 'visible' && Date.now() - lastRefresh >= REFRESH_MS) refreshOrders(false).catch(() => {});
	});

	const check = (kind, o, label, on) => `<label class="bk-g-check"><input type="checkbox" data-flag="${kind}" data-id="${o.id}" ${on ? 'checked' : ''}><span class="bk-g-mlabel">${label}</span><span class="bk-g-sr">Pedido ${esc(o.number)}: ${label.toLowerCase()}</span></label>`;

	// Sin columna Consecutivo (repetía el número): se sigue buscando por consecutivo y sale en el detalle e impresión.
	const paintOrders = (box, d) => {
		if (!seenIds.size) rememberIds(d);
		const showDisp = d.orders.some((o) => o.dispatched !== null);
		box.innerHTML = d.orders.length ? `
			<p class="bk-g-count">${d.total} pedido${d.total === 1 ? '' : 's'}</p>
			<div class="bk-g-table-wrap"><table class="bk-g-table bk-g-orders">
				<thead><tr><th>Pedido</th><th>Fecha</th><th>Clienta</th><th>Origen</th><th>Total</th><th>Estado</th><th>Pago confirmado</th><th>Impreso</th>${showDisp ? '<th>Despachado</th>' : ''}<th><span class="bk-g-sr">Imprimir</span></th></tr></thead>
				<tbody>${d.orders.map((o) => `<tr data-row="${o.id}">
					<td class="c-num"><button type="button" class="bk-g-link" data-order="${o.id}">#${esc(o.number)}</button></td>
					<td class="c-date">${esc(o.date)}</td>
					<td class="c-cust">${esc(o.customer)}<small>${esc(o.city)} · ${o.items} prenda${o.items === 1 ? '' : 's'}${o.nfiles ? ` · <span class="bk-g-nfiles" title="Archivos del pedido">📎 ${o.nfiles}</span>` : ''}</small></td>
					<td class="c-src">${srcChip(o.source) || '—'}</td>
					<td class="c-total"><b>${esc(o.total)}</b><small>${esc(o.payment)}</small></td>
					<td class="c-status"><span class="bk-g-pill is-${esc(o.status)}">${esc(statusLabel(o.status))}</span>${o.tracking ? `<small class="bk-g-trk">${C.icons.truck} ${esc(C.carriers[o.tracking.carrier] || '')}</small>` : ''}</td>
					<td class="c-print c-paid">${check('paid_ok', o, 'Pago confirmado', o.paid_ok)}</td>
					<td class="c-print">${check('printed', o, 'Impreso', o.printed)}</td>
					${showDisp ? `<td class="c-print c-disp">${check('dispatched', o, 'Despachado', o.dispatched)}</td>` : ''}
					<td class="c-act"><button type="button" class="bk-g-btn is-ghost is-small" data-print="${o.id}">${C.icons.print}<span>Imprimir</span><span class="bk-g-sr"> pedido ${esc(o.number)}</span></button></td>
				</tr>`).join('')}</tbody>
			</table></div>
			${pager(d.pages, oState.page, 'o')}` : '<p class="bk-g-empty">No hay pedidos con esos filtros.</p>';
	};

	const pager = (pages, page, kind) => pages > 1 ? `<nav class="bk-g-pager" aria-label="Páginas">
		<button type="button" class="bk-g-btn is-ghost" data-page="${page - 1}" data-kind="${kind}" ${page <= 1 ? 'disabled' : ''}>Anterior</button>
		<span>Página ${page} de ${pages}</span>
		<button type="button" class="bk-g-btn is-ghost" data-page="${page + 1}" data-kind="${kind}" ${page >= pages ? 'disabled' : ''}>Siguiente</button></nav>` : '';

	/* --- Detalle de pedido (panel lateral) --------------------------------------------- */
	const drawer = $('#bk-g-drawer');
	const panel = $('.bk-g-drawer__panel');
	let lastFocus = null;
	const openDrawer = (html) => {
		lastFocus = document.activeElement;
		panel.innerHTML = html;
		drawer.hidden = false;
		requestAnimationFrame(() => drawer.classList.add('is-open'));
		$('[data-close]', panel)?.focus();
	};
	const closeDrawer = () => {
		drawer.classList.remove('is-open');
		setTimeout(() => { drawer.hidden = true; }, 200);
		lastFocus?.focus?.();
	};
	drawer.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) closeDrawer(); });
	document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !drawer.hidden) closeDrawer(); });

	// Archivos del pedido (repeater ACF "Archivos Pedidos"): siempre visible, con subir y quitar.
	const filesHtml = (o) => !o.files ? '' : `<section class="bk-g-fsec"><h3>${esc(o.files.label)}</h3>
		${o.files.rows.length ? `<ul class="bk-g-files">${o.files.rows.map((r) => `<li class="bk-g-file">
			${r.files.map((a) => `<a href="${esc(a.url)}" target="_blank" rel="noopener" class="bk-g-file__link">${a.thumb ? `<img src="${esc(a.thumb)}" alt="" width="96" height="96">` : `<span class="bk-g-file__doc">${a.pdf ? 'PDF' : 'Archivo'}</span>`}<small>${esc(a.name)}</small></a>`).join('')}
			${r.texts.map((x) => `<p class="bk-g-file__txt"><b>${esc(x.label)}:</b> ${esc(x.value)}</p>`).join('')}
			<button type="button" class="bk-g-icon is-danger" data-file-del="${r.index}" data-id="${o.id}" aria-label="Quitar el archivo ${r.n}">${C.icons.trash}</button></li>`).join('')}</ul>` : '<p class="bk-g-empty">Este pedido no tiene archivos.</p>'}
		<label class="bk-g-btn is-ghost is-small bk-g-upload">${C.icons.plus} Subir archivo<input type="file" class="bk-g-sr" data-file-up="${o.id}" accept="application/pdf,image/jpeg,image/png,image/webp"></label>
		<small class="bk-g-hint">PDF, JPG, PNG o WebP · máx. ${esc(o.files.max)}. Se guarda en el mismo campo de ACF (se ve igual en WooCommerce).</small></section>`;

	// Historial: cuándo se creó, pagó, cambió de estado, se imprimió, despachó, envió la guía…
	const historyHtml = (o) => o.history?.length ? `<section><h3>Historial del pedido</h3><ol class="bk-g-hist">${[...o.history].reverse().map((h) => `<li class="is-${esc(h.type)}"><b>${esc(h.label)}</b><small>${esc(h.date)}${h.by ? ` · ${esc(h.by)}` : ''}</small></li>`).join('')}</ol></section>` : '';

	// Editar los datos de la clienta en este pedido (facturación y envío + cédula).
	const custField = (g, k, label, v, extra = '') => `<label><span>${esc(label)}</span><input name="${g}.${k}" value="${esc(v || '')}" ${extra}></label>`;
	const custState = (g, v, states) => `<label><span>Departamento</span>${Object.keys(states).length ? `<select name="${g}.state"><option value="">Elige…</option>${Object.entries(states).map(([k, n]) => `<option value="${esc(k)}" ${v === k ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>` : `<input name="${g}.state" value="${esc(v || '')}">`}</label>`;
	const custAddr = (g, d, states) => `${custState(g, d.state, states)}${custField(g, 'city', 'Ciudad', d.city, 'autocomplete="off"')}
		<label class="is-wide"><span>Dirección</span><input name="${g}.address_1" value="${esc(d.address_1 || '')}" autocomplete="off"></label>
		<label class="is-wide"><span>Apto, torre, barrio</span><input name="${g}.address_2" value="${esc(d.address_2 || '')}" autocomplete="off"></label>`;
	const custFormHtml = (o) => {
		if (!o.edit) return '';
		const e = o.edit; const b = e.billing; const sh = e.shipping;
		return `<form id="bk-g-custform" class="bk-g-custform" data-id="${o.id}" hidden novalidate>
			<div class="bk-g-custgrid">
				${custField('billing', 'first_name', 'Nombre', b.first_name, 'required autocomplete="off"')}
				${custField('billing', 'last_name', 'Apellidos', b.last_name, 'autocomplete="off"')}
				${e.has_ced ? `<label><span>Cédula</span><input name="cedula" value="${esc(e.cedula)}" inputmode="numeric" autocomplete="off"></label>` : ''}
				${custField('billing', 'phone', 'Celular', b.phone, 'type="tel" inputmode="tel" autocomplete="off"')}
				<label class="is-wide"><span>Correo</span><input name="billing.email" type="email" value="${esc(b.email || '')}" autocomplete="off"></label>
				${custAddr('billing', b, e.states)}
			</div>
			<label class="bk-g-switch"><input type="checkbox" name="same" ${e.same ? 'checked' : ''}><span>Enviar a la misma dirección</span></label>
			<fieldset class="bk-g-custship" ${e.same ? 'hidden' : ''}><legend>Datos de envío</legend><div class="bk-g-custgrid">
				${custField('shipping', 'first_name', 'Nombre', sh.first_name)}${custField('shipping', 'last_name', 'Apellidos', sh.last_name)}
				${custField('shipping', 'phone', 'Celular', sh.phone, 'type="tel" inputmode="tel"')}
				${custAddr('shipping', sh, e.states)}</div></fieldset>
			<p class="bk-g-formerr" role="alert" hidden></p>
			<p class="bk-g-hint">Se cambia solo en este pedido (no en la cuenta de la clienta) y queda en el historial.</p>
			<div class="bk-g-dactions"><button type="submit" class="bk-g-btn">${C.icons.check} Guardar datos</button><button type="button" class="bk-g-btn is-ghost" data-cust-cancel>Cancelar</button></div>
		</form>`;
	};

	// Pedido sin pagar: recordatorios automáticos (1 h y 12 h), cancelación (24 h), enviar a mano, detener, enlace de pago.
	const payremHtml = (o) => {
		const p = o.payrem;
		if (!p) return '';
		const li = (x, done) => `<li class="${done ? 'is-done' : x.cancel ? 'is-cancel' : ''}">${done ? C.icons.check : (x.cancel ? C.icons.x : C.icons.clock)}<span>${esc(x.label)}</span><small>${esc(x.date)}</small></li>`;
		return `<section class="bk-g-payrem" id="bk-g-payrem" data-id="${o.id}"><h3>${C.icons.card} ${p.unpaid ? 'Pago pendiente' : 'Recordatorios de pago'}</h3>
			<p class="bk-g-hint">${p.unpaid ? (p.stopped ? 'La clienta aún no paga. Los recordatorios y la cancelación automática están <b>detenidos</b>.' : 'La clienta aún no paga. Recibe un recordatorio a la hora y otro a las 12 horas; si a las 24 horas no paga, el pedido se cancela solo y las prendas vuelven al inventario.') : (p.cancelled ? `Cancelado automáticamente el ${esc(p.cancelled)} por falta de pago.` : 'El pedido ya no está pendiente de pago.')}</p>
			${p.sent.length || p.next.length ? `<ol class="bk-g-pptl">${p.sent.map((x) => li(x, true)).join('')}${p.next.map((x) => li(x, false)).join('')}</ol>` : ''}
			${p.unpaid ? `<div class="bk-g-dactions">
				<button type="button" class="bk-g-btn" data-pp="preview" ${p.can_send ? '' : 'disabled'}>${C.icons.eye || ''} Enviar recordatorio ahora</button>
				<button type="button" class="bk-g-btn is-ghost" data-pp="copy" data-url="${esc(p.pay_url)}">${C.icons.copy} Copiar enlace de pago</button>
				<button type="button" class="bk-g-btn is-ghost" data-pp="${p.stopped ? 'resume' : 'stop'}">${p.stopped ? 'Reanudar automáticos' : 'Detener automáticos'}</button></div>
				${p.can_send ? '' : `<small class="bk-g-hint">El pedido se creó hace poco: la clienta puede estar pagando. Podrás enviar el recordatorio en ${p.wait} min.</small>`}
				<div class="bk-g-pppv" hidden></div>` : ''}
		</section>`;
	};

	const orderHtml = (o) => `
		<header class="bk-g-dhead"><div><h2 id="bk-g-dtitle">Pedido #${esc(o.number)}</h2><small>${esc(o.date)}${o.consecutivo ? ` · Consecutivo ${esc(o.consecutivo)}` : ''}</small></div>
			<button type="button" class="bk-g-icon" data-close aria-label="Cerrar">${C.icons.x}</button></header>
		<div class="bk-g-dbody">
			<div class="bk-g-row2">
				<label><span>Estado</span><select id="bk-g-ostatus">${Object.entries(C.statuses).map(([k, v]) => `<option value="${k}" ${o.status === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
				<label class="bk-g-switch"><input type="checkbox" id="bk-g-opaid" ${o.paid_ok ? 'checked' : ''}><span>Pago confirmado</span></label>
				<label class="bk-g-switch"><input type="checkbox" id="bk-g-oprinted" ${o.printed ? 'checked' : ''}><span>Impreso</span></label>
				${o.dispatched !== null && o.dispatched !== undefined ? `<label class="bk-g-switch"><input type="checkbox" id="bk-g-odispatched" ${o.dispatched ? 'checked' : ''}><span>Despachado</span></label>` : ''}
			</div>
			<div class="bk-g-dactions"><button type="button" class="bk-g-btn" id="bk-g-osave" data-id="${o.id}">Guardar estado</button>
				<button type="button" class="bk-g-btn is-ghost" data-print="${o.id}">${C.icons.print} Imprimir pedido</button></div>
			${payremHtml(o)}${o.payrem?.unpaid ? '' : shipHtml(o)}
			<section class="bk-g-cust"><div class="bk-g-cust__head"><h3>Clienta</h3>${o.edit ? `<button type="button" class="bk-g-btn is-ghost is-small" data-cust-edit aria-expanded="false" aria-controls="bk-g-custform">${C.icons.edit} Editar datos</button>` : ''}</div>
				${custFormHtml(o)}<p class="bk-g-cust__view"><b>${esc(o.customer)}</b>${o.fields?.cedula || o.cedula ? `<br>Cédula: ${esc(o.cedula || '—')}` : ''}${o.fields?.consecutivo ? `<br>Consecutivo: ${esc(o.consecutivo || '—')}` : ''}${o.source ? `<br><span class="bk-g-srcline">Origen de la venta: ${srcChip(o.source, true)}</span>` : (o.origin ? `<br><small>Origen de la venta: ${esc(o.origin)}</small>` : '')}<br>
				${o.phone ? `<a href="tel:${esc(o.phone)}">${esc(o.phone)}</a> · <a href="https://wa.me/57${esc(String(o.phone).replace(/\D/g, '').replace(/^57/, ''))}" target="_blank" rel="noopener">WhatsApp</a><br>` : ''}
				<a href="mailto:${esc(o.email)}">${esc(o.email)}</a><br>${esc(o.address)}</p>
				${o.note ? `<p class="bk-g-note"><b>Nota de la clienta:</b> ${esc(o.note)}</p>` : ''}</section>
			<section><h3>Productos</h3><ul class="bk-g-items">${o.items.map((i) => `<li>${i.image ? `<img src="${esc(i.image)}" alt="" width="48" height="48">` : '<span></span>'}
				<div><b>${esc(i.name)}</b><small>${esc(i.meta)}${i.sku ? ` · REF ${esc(i.sku)}` : ''}</small></div><span>×${i.qty}</span><b>${esc(i.total)}</b></li>`).join('')}</ul>
				<dl class="bk-g-totals"><div><dt>Subtotal</dt><dd>${esc(o.subtotal)}</dd></div>${o.discount ? `<div><dt>Descuento</dt><dd>${esc(o.discount)}</dd></div>` : ''}<div><dt>Envío</dt><dd>${esc(o.shipping)}</dd></div><div class="is-total"><dt>Total</dt><dd>${esc(o.total)}</dd></div></dl>
				<p><small>Pago: ${esc(o.payment)}</small></p></section>
			${filesHtml(o)}
			${historyHtml(o)}
			${o.extra?.length ? `<details class="bk-g-extra"><summary>Otros datos del pedido (${o.extra.length})</summary><dl>${o.extra.map((x) => `<div><dt title="${esc(x.key)}">${esc(x.label)}</dt><dd>${esc(x.value)}</dd></div>`).join('')}</dl></details>` : ''}
			<section><h3>Notas</h3>
				<form id="bk-g-onote" data-id="${o.id}"><label for="bk-g-notetext" class="bk-g-sr">Nueva nota</label>
					<textarea id="bk-g-notetext" rows="2" placeholder="Escribe una nota del pedido"></textarea>
					<label class="bk-g-switch"><input type="checkbox" id="bk-g-notecust"><span>Enviar a la clienta</span></label>
					<button class="bk-g-btn is-ghost" type="submit">Añadir nota</button></form>
				<ul class="bk-g-notes">${o.notes.map((n) => `<li class="${n.customer ? 'is-customer' : ''}"><p>${esc(n.content)}</p><small>${esc(n.date)}${n.by ? ` · ${esc(n.by)}` : ''}${n.customer ? ' · enviada a la clienta' : ''}</small></li>`).join('')}</ul></section>
			<a class="bk-g-link" href="${esc(o.edit_url)}" target="_blank" rel="noopener">Abrir en WooCommerce ${C.icons.ext}</a>
		</div>`;

	/* --- Guía de envío ------------------------------------------------------------ */
	const isLocal = (k) => !!k && (C.carriersLocal || []).includes(k);
	const shipHtml = (o) => `<section class="bk-g-ship"><h3>${C.icons.truck} Enviar guía de envío</h3>
		${o.tracking ? `<p class="bk-g-shipped">Enviado con <b>${esc(C.carriers[o.tracking.carrier] || o.tracking.carrier)}</b> · ${o.tracking.number ? `guía <b>${esc(o.tracking.number)}</b>` : 'entrega local (sin guía)'}<small>${esc(o.tracking.date)}${o.tracking.sent_by ? ` · ${esc(o.tracking.sent_by)}` : ''}</small></p>` : ''}
		<form id="bk-g-shipform" data-id="${o.id}" novalidate>
			<div class="bk-g-row2">
				<label><span>Transportadora</span><select name="carrier" required><option value="">Elige…</option>${Object.entries(C.carriers).map(([k, v]) => `<option value="${k}" ${o.tracking?.carrier === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
				<label data-ship-number ${isLocal(o.tracking?.carrier) ? 'hidden' : ''}><span>Número de guía</span><input name="number" required inputmode="text" autocomplete="off" value="${esc(o.tracking?.number || '')}" placeholder="Ej.: 2401234567"></label>
			</div>
			<p class="bk-g-hint" data-ship-local ${isLocal(o.tracking?.carrier) ? '' : 'hidden'}>Entrega local (domicilios Medellín y área metropolitana): no necesita número de guía. La clienta recibe el correo "Tu pedido llega hoy".</p>
			${o.status !== 'completed' ? '<label class="bk-g-switch"><input type="checkbox" name="complete" checked><span>Marcar como Completado (sin el correo estándar de WooCommerce)</span></label>' : ''}
			<p class="bk-g-formerr" role="alert" hidden></p>
			<button type="submit" class="bk-g-btn">${C.icons.mail} ${o.tracking ? 'Reenviar correo' : 'Ver correo antes de enviar'}</button>
		</form></section>`;

	const pv = $('#bk-g-preview');
	const pvBox = $('.bk-g-preview__box');
	let pvReturn = null;
	let pendingShip = null; // { id, body } del envío que se está confirmando.
	const openPreview = (html) => {
		pvReturn = document.activeElement;
		pvBox.innerHTML = html;
		pv.hidden = false;
		$('[data-pv-focus]', pvBox)?.focus();
	};
	const closePreview = () => { pendingShip = null; pv.hidden = true; pvBox.innerHTML = ''; pvReturn?.focus?.(); };
	pv.addEventListener('click', (e) => { if (e.target === pv || e.target.closest('[data-pv-close]')) closePreview(); });
	document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !pv.hidden) { e.stopImmediatePropagation(); closePreview(); } }, true);

	const previewHtml = (d, actions) => `
		<header class="bk-g-pvhead"><h2 id="bk-g-ptitle">Vista previa del correo</h2><button type="button" class="bk-g-icon" data-pv-close aria-label="Cerrar">${C.icons.x}</button></header>
		<dl class="bk-g-pvmeta">${d.to ? `<div><dt>Para</dt><dd>${esc(d.to)}</dd></div>` : ''}<div><dt>Asunto</dt><dd>${esc(d.subject)}</dd></div></dl>
		<iframe class="bk-g-pvframe" title="Vista previa del correo" sandbox=""></iframe>
		<footer class="bk-g-pvfoot">${actions}</footer>`;

	const fillFrame = (html) => { const f = $('.bk-g-pvframe', pvBox); if (f) f.srcdoc = html; };

	let openId = 0;
	const showOrder = async (id) => {
		openId = String(id);
		const old = getCached(`orders/${id}`);
		openDrawer(old ? orderHtml(old) : '<div class="bk-g-loading">Cargando pedido…</div>');
		try {
			const d = await fetchFresh(`orders/${id}`);
			if (openId !== String(id) || drawer.hidden) return;
			if (JSON.stringify(d) !== JSON.stringify(old)) { panel.innerHTML = orderHtml(d); $('[data-close]', panel)?.focus(); }
		} catch (e) { if (!old) panel.innerHTML = `<p class="bk-g-error">${esc(e.message)}</p>`; }
	};
	// El detalle se pide al acercar el cursor o el foco: al hacer clic ya está listo.
	const prefetch = (e) => {
		const b = e.target.closest?.('[data-order]');
		if (b && !getCached(`orders/${b.dataset.order}`)) fetchFresh(`orders/${b.dataset.order}`).catch(() => {});
	};
	document.addEventListener('pointerover', prefetch, { passive: true });
	document.addEventListener('focusin', prefetch);
	const setOrder = (o) => {
		memo.set(`orders/${o.id}`, o);
		forget('orders?');
		forget('summary');
		if (!drawer.hidden && openId === String(o.id)) panel.innerHTML = orderHtml(o);
	};

	// Imprimir: hoja con todo el detalle. En computador se imprime sin salir del panel; en celular abre una pestaña.
	const printOrder = (id) => {
		const url = `${C.printUrl}${id}&auto=1`;
		if (matchMedia('(pointer: coarse)').matches) { window.open(url, '_blank', 'noopener'); return; }
		document.getElementById('bk-g-printframe')?.remove();
		const f = document.createElement('iframe');
		f.id = 'bk-g-printframe';
		f.title = 'Impresión del pedido';
		f.className = 'bk-g-printframe';
		f.src = `${C.printUrl}${id}`;
		f.onload = () => { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (err) { window.open(url, '_blank', 'noopener'); } };
		document.body.appendChild(f);
	};

	/* --- Productos ---------------------------------------------------------------- */
	const pState = { q: '', line: '', stock: '', page: 1 };
	function viewProducts() {
		main.innerHTML = `<div class="bk-g-h1row"><h1 class="bk-g-h1">Productos</h1><a class="bk-g-btn" href="#productos/nuevo">${C.icons.plus} Nuevo producto</a></div>
			<form class="bk-g-filters" id="bk-g-pf" role="search">
				<label class="bk-g-search"><span class="bk-g-sr">Buscar productos</span>${C.icons.search}<input type="search" name="q" value="${esc(pState.q)}" placeholder="Nombre o REF" autocomplete="off"></label>
				<label><span>Línea</span><select name="line"><option value="">Todas</option>${Object.entries(C.lines).map(([k, v]) => `<option value="${k}" ${pState.line === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
				<label><span>Stock</span><select name="stock"><option value="">Todos</option><option value="in" ${pState.stock === 'in' ? 'selected' : ''}>Con stock</option><option value="out" ${pState.stock === 'out' ? 'selected' : ''}>Agotados</option></select></label>
				<button type="submit" class="bk-g-btn">Buscar</button>
			</form><div id="bk-g-plist" aria-live="polite"></div>`;
		const form = $('#bk-g-pf');
		let t = 0;
		const read = () => Object.assign(pState, Object.fromEntries(new FormData(form).entries()), { page: 1 });
		form.addEventListener('submit', (e) => { e.preventDefault(); read(); loadProducts(); });
		form.addEventListener('change', (e) => { if (e.target.name !== 'q') { read(); loadProducts(); } });
		form.q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { read(); loadProducts(); }, 450); });
		loadProducts();
	}

	async function loadProducts() {
		const box = $('#bk-g-plist');
		if (!box) return;
		const seq = ++pSeq;
		const path = `products?${qs(pState)}`;
		const old = getCached(path);
		if (old) paintProducts(box, old); else box.innerHTML = '<div class="bk-g-loading">Cargando productos…</div>';
		try {
			const d = await fetchFresh(path);
			if (seq !== pSeq || !box.isConnected) return;
			if (JSON.stringify(d) !== JSON.stringify(old)) paintProducts(box, d);
		} catch (e) { if (!old) box.innerHTML = `<p class="bk-g-error">${esc(e.message)}</p>`; }
	}

	const paintProducts = (box, d) => {
		box.innerHTML = d.products.length ? `<p class="bk-g-count">${d.total} producto${d.total === 1 ? '' : 's'}</p>
				<ul class="bk-g-plist">${d.products.map((p) => `<li class="bk-g-prod" data-pid="${p.id}">
					<div class="bk-g-prow">
						${p.image ? `<img src="${esc(p.image)}" alt="" width="56" height="56">` : '<span class="bk-g-noimg"></span>'}
						<div class="bk-g-pinfo"><b>${esc(p.name)}</b><small>REF ${esc(p.sku || '—')} · ${esc(p.line || 'Sin línea')}${p.status !== 'publish' ? ` · ${esc(p.status)}` : ''}</small></div>
						<span class="bk-g-pprice">${esc(p.price)}</span>
						<span class="bk-g-pill ${p.stock === 'instock' ? 'is-completed' : 'is-cancelled'}">${p.stock === 'instock' ? 'Con stock' : 'Agotado'}</span>
						<button type="button" class="bk-g-star ${p.featured ? 'is-on' : ''}" data-feat="${p.id}" aria-pressed="${p.featured}" title="Destacado = etiqueta Nuevo">${C.icons.prod}<span class="bk-g-sr">Nuevo (destacado): ${esc(p.name)}</span></button>
						<button type="button" class="bk-g-btn is-ghost" data-sizes="${p.id}" aria-expanded="false">Tallas y precios</button>
						<a class="bk-g-btn is-ghost" href="#productos/editar/${p.id}">${C.icons.edit} Editar<span class="bk-g-sr">: ${esc(p.name)}</span></a>
					</div><div class="bk-g-vars" hidden></div></li>`).join('')}</ul>${pager(d.pages, pState.page, 'p')}` : '<p class="bk-g-empty">No hay productos con esos filtros.</p>';
	};

	const varsHtml = (p) => p.variations.length ? `<div class="bk-g-table-wrap"><table class="bk-g-table bk-g-vtable">
		<thead><tr><th>Talla</th><th>Precio normal</th><th>Precio rebajado</th><th>Stock</th><th></th></tr></thead>
		<tbody>${p.variations.map((v) => `<tr data-vid="${v.id}">
			<th scope="row">${esc(v.size)}</th>
			<td><label class="bk-g-sr" for="r${v.id}">Precio normal talla ${esc(v.size)}</label><input id="r${v.id}" name="regular" inputmode="numeric" value="${esc(v.regular)}"></td>
			<td><label class="bk-g-sr" for="s${v.id}">Precio rebajado talla ${esc(v.size)}</label><input id="s${v.id}" name="sale" inputmode="numeric" value="${esc(v.sale)}" placeholder="—"></td>
			<td><label class="bk-g-sr" for="k${v.id}">Stock talla ${esc(v.size)}</label><input id="k${v.id}" name="stock" inputmode="numeric" value="${v.manage ? esc(v.stock) : ''}" placeholder="${v.status === 'instock' ? 'Sin control' : '0'}"></td>
			<td><button type="button" class="bk-g-btn is-small" data-vsave="${v.id}">Guardar</button></td></tr>`).join('')}</tbody></table></div>
		<p class="bk-g-hint">Deja el precio rebajado vacío para quitar la oferta. <a href="${esc(p.edit_url)}" target="_blank" rel="noopener">Editar fotos y descripción en WooCommerce</a></p>` : '<p class="bk-g-empty">Este producto no tiene tallas.</p>';

	/* --- Ajustes (solo administradores) --------------------------------------------------- */
	async function viewSettings() {
		main.innerHTML = '<h1 class="bk-g-h1">Ajustes</h1><div class="bk-g-loading">Cargando…</div>';
		const seq = viewSeq;
		try {
			const d = await api('settings');
			if (seq !== viewSeq) return;
			const f = d.fields;
			main.innerHTML = `<h1 class="bk-g-h1">Ajustes</h1>
				<section class="bk-g-card"><h2>Campos de los pedidos</h2>
				<p class="bk-g-hint">Indica dónde se guardan hoy estos datos para que el dashboard los muestre y busque, sin cambiar nada de los pedidos existentes.</p>
				<form id="bk-g-sf" class="bk-g-sform">
					<label><span>Consecutivo</span><input name="consecutivo" value="${esc(f.consecutivo)}" placeholder="Ej.: _wcdn_invoice_number"></label>
					<label><span>Check "Impreso"</span><input name="impreso" value="${esc(f.impreso)}"></label>
					<label><span>Check "Despachado"</span><input name="despachado" value="${esc(f.despachado)}"></label>
					<label><span>Check "Pago confirmado"</span><input name="pago" value="${esc(f.pago)}"></label>
					<label><span>Cédula (una o varias, separadas por coma)</span><input name="cedula" value="${esc(f.cedula.join(', '))}"></label>
					<label><span>Archivos del pedido (repeater ACF)</span><input name="adjuntos" value="${esc(f.adjuntos)}"></label>
					<label><span>Usuarios que solo ven SEO y ADS (nombres de usuario, separados por coma)</span><input name="seo_users" value="${esc((d.seo_users || []).join(', '))}"></label>
					<button class="bk-g-btn" type="submit">Guardar campos</button>
				</form></section>
				<section class="bk-g-card"><h2>Campos encontrados en los últimos 40 pedidos</h2>
				<p class="bk-g-hint">Usa esta lista para identificar el consecutivo, la cédula, el impreso y el despachado. Toca un botón para asignarlo.</p>
				<div class="bk-g-table-wrap"><table class="bk-g-table"><thead><tr><th>Campo</th><th>Ejemplo</th><th>Pedidos</th><th>Usar como</th></tr></thead><tbody>
				${d.meta.map((m) => `<tr><td><code>${esc(m.key)}</code></td><td>${esc(m.example)}</td><td>${m.orders}</td><td class="bk-g-use">
					<button type="button" class="bk-g-btn is-small is-ghost" data-use="consecutivo" data-key="${esc(m.key)}">Consecutivo</button>
					<button type="button" class="bk-g-btn is-small is-ghost" data-use="cedula" data-key="${esc(m.key)}">Cédula</button>
					<button type="button" class="bk-g-btn is-small is-ghost" data-use="impreso" data-key="${esc(m.key)}">Impreso</button>
					<button type="button" class="bk-g-btn is-small is-ghost" data-use="despachado" data-key="${esc(m.key)}">Despachado</button></td></tr>`).join('') || '<tr><td colspan="4">Aún no hay pedidos.</td></tr>'}
				</tbody></table></div></section>
				<p class="bk-g-hint">Las vistas previas y pruebas de correos están en <a href="#correos">Correos</a>.</p>`;
		} catch (e) { main.innerHTML = `<p class="bk-g-error">${esc(e.message)}</p>`; }
	}

	/* --- Eventos delegados -------------------------------------------------------------- */
	document.addEventListener('click', async (e) => {
		const ref = e.target.closest?.('[data-orders-refresh]');
		if (ref) { await busy(ref, () => refreshOrders(true)); return; }
		const t = e.target;
		const ord = t.closest('[data-order]');
		if (ord) { showOrder(ord.dataset.order); return; }

		const pg = t.closest('[data-page]');
		if (pg) {
			if (pg.dataset.kind === 'o') { oState.page = Number(pg.dataset.page); loadOrders(); } else if (pg.dataset.kind === 'p') { pState.page = Number(pg.dataset.page); loadProducts(); } else { window.bkGExtra?.page(pg.dataset.kind, Number(pg.dataset.page)); window.bkGMore?.page?.(pg.dataset.kind, Number(pg.dataset.page)); }
			main.focus();
			return;
		}

		const pr = t.closest('[data-print]');
		if (pr) {
			printOrder(pr.dataset.print);
			// Imprimir = marcar como impreso (se puede desmarcar).
			const row = $(`[data-flag="printed"][data-id="${pr.dataset.print}"]`);
			const inDrawer = $('#bk-g-oprinted');
			if ((row && !row.checked) || (!row && inDrawer && !inDrawer.checked)) {
				api(`orders/${pr.dataset.print}`, { method: 'POST', body: { printed: true } }).then((o) => {
					setOrder(o);
					if (row) row.checked = true;
					toast(`Pedido #${o.number} marcado como impreso`);
				}).catch(() => {});
			}
			return;
		}

		const fdel = t.closest('[data-file-del]');
		if (fdel) {
			if (!window.confirm('¿Quitar este archivo del pedido? (El archivo sigue en la Mediateca.)')) return;
			await busy(fdel, async () => {
				setOrder(await api(`orders/${fdel.dataset.id}/files/delete`, { method: 'POST', body: { index: Number(fdel.dataset.fileDel) } }));
				toast('Archivo quitado');
			});
			return;
		}

		const pp = t.closest('[data-pp]');
		if (pp) {
			const box = $('#bk-g-payrem'); const id = box.dataset.id; const act = pp.dataset.pp;
			if (act === 'copy') {
				try { await navigator.clipboard.writeText(pp.dataset.url); toast('Enlace de pago copiado: pégalo en WhatsApp'); } catch { window.prompt('Copia el enlace de pago:', pp.dataset.url); }
				return;
			}
			await busy(pp, async () => {
				try {
					if (act === 'preview') {
						const d = await api(`orders/${id}/payment-reminder`, { method: 'POST', body: { action: 'preview' } });
						const pv = $('.bk-g-pppv', box);
						pv.hidden = false;
						pv.innerHTML = `<p class="bk-g-pvmeta"><b>Para:</b> ${esc(d.to)}<br><b>Asunto:</b> ${esc(d.subject)}</p><iframe class="bk-g-pvframe" title="Vista previa del recordatorio de pago"></iframe>
							<div class="bk-g-dactions"><button type="button" class="bk-g-btn" data-pp="send">${C.icons.send || ''} Confirmar y enviar</button><button type="button" class="bk-g-btn is-ghost" data-pp="close">Cancelar</button></div>`;
						$('iframe', pv).srcdoc = d.html;
						$('[data-pp="send"]', pv).focus();
						return;
					}
					if (act === 'close') { const pv = $('.bk-g-pppv', box); pv.hidden = true; pv.innerHTML = ''; return; }
					const o = await api(`orders/${id}/payment-reminder`, { method: 'POST', body: { action: act } });
					setOrder(o);
					toast({ send: 'Recordatorio de pago enviado', stop: 'Recordatorios automáticos detenidos', resume: 'Recordatorios automáticos reanudados' }[act] || 'Listo');
				} catch (er) { toast(er.message, 'err'); }
			});
			return;
		}

		const ce = t.closest('[data-cust-edit], [data-cust-cancel]');
		if (ce) {
			const f = $('#bk-g-custform'); const btn = $('[data-cust-edit]');
			const open = ce.matches('[data-cust-edit]') ? f.hidden : false;
			if (!open) f.reset();
			f.hidden = !open; $('.bk-g-cust__view').hidden = open;
			btn.setAttribute('aria-expanded', String(open));
			if (open) f.querySelector('input')?.focus(); else btn.focus();
			return;
		}

		const save = t.closest('#bk-g-osave');
		if (save) {
			await busy(save, async () => {
				const o = await api(`orders/${save.dataset.id}`, { method: 'POST', body: { status: $('#bk-g-ostatus').value, paid_ok: $('#bk-g-opaid').checked, printed: $('#bk-g-oprinted').checked, ...($('#bk-g-odispatched') ? { dispatched: $('#bk-g-odispatched').checked } : {}) } });
				setOrder(o);
				toast(`Pedido #${o.number}: ${statusLabel(o.status)}`);
				loadOrders();
			});
			return;
		}

		const sizes = t.closest('[data-sizes]');
		if (sizes) {
			const box = sizes.closest('.bk-g-prod').querySelector('.bk-g-vars');
			const open = sizes.getAttribute('aria-expanded') !== 'true';
			sizes.setAttribute('aria-expanded', String(open));
			box.hidden = !open;
			if (open) {
				box.innerHTML = '<div class="bk-g-loading">Cargando tallas…</div>';
				try { box.innerHTML = varsHtml(await api(`products/${sizes.dataset.sizes}`)); } catch (err) { box.innerHTML = `<p class="bk-g-error">${esc(err.message)}</p>`; }
			}
			return;
		}

		const vs = t.closest('[data-vsave]');
		if (vs) {
			const row = vs.closest('tr');
			await busy(vs, async () => {
				const body = Object.fromEntries($$('input', row).map((i) => [i.name, i.value.replace(/[^\d.,]/g, '').replace(',', '.')]));
				const v = await api(`variations/${vs.dataset.vsave}`, { method: 'POST', body });
				forget('products');
				forget('summary');
				row.querySelector('[name="regular"]').value = v.regular;
				row.querySelector('[name="sale"]').value = v.sale;
				row.classList.add('is-saved');
				setTimeout(() => row.classList.remove('is-saved'), 1500);
				toast(`Talla ${row.querySelector('th').textContent} guardada`);
			});
			return;
		}

		const feat = t.closest('[data-feat]');
		if (feat) {
			await busy(feat, async () => {
				const on = feat.getAttribute('aria-pressed') !== 'true';
				await api(`products/${feat.dataset.feat}`, { method: 'POST', body: { featured: on } });
				forget('products');
				feat.setAttribute('aria-pressed', String(on));
				feat.classList.toggle('is-on', on);
				toast(on ? 'Marcado como Nuevo' : 'Ya no aparece como Nuevo');
			});
			return;
		}

		const confirmShip = t.closest('[data-ship-confirm]');
		if (confirmShip) {
			await busy(confirmShip, async () => {
				if (!pendingShip) return;
				const o = await api(`orders/${pendingShip.id}/shipment`, { method: 'POST', body: { ...pendingShip.body, confirm: true } });
				pendingShip = null;
				closePreview();
				setOrder(o);
				toast(`Correo enviado a ${o.email}`);
				loadOrders();
			});
			return;
		}

		const sample = t.closest('[data-ship-sample]');
		if (sample) {
			await busy(sample, async () => {
				const d = await api('shipment-sample', { method: 'POST', body: { carrier: $('#bk-g-shiptest').carrier.value } });
				openPreview(previewHtml({ subject: `${d.subject} (ejemplo con el pedido #${d.order})` }, '<button type="button" class="bk-g-btn" data-pv-close data-pv-focus>Cerrar</button>'));
				fillFrame(d.html);
			});
			return;
		}

		const use = t.closest('[data-use]');
		if (use) {
			const form = $('#bk-g-sf');
			const input = form[use.dataset.use];
			input.value = use.dataset.use === 'cedula' && input.value ? `${input.value}, ${use.dataset.key}` : use.dataset.key;
			input.focus();
			toast('Revisa y toca "Guardar campos"');
		}
	});

	const flagMsg = {
		paid_ok: ['Pago confirmado', 'Pago sin confirmar'],
		printed: ['Marcado como impreso', 'Marcado como no impreso'],
		dispatched: ['Marcado como despachado', 'Marcado como no despachado'],
	};
	document.addEventListener('change', async (e) => {
		const up = e.target.closest('[data-file-up]');
		if (up && up.files[0]) {
			const label = up.closest('label');
			label.classList.add('is-busy');
			try {
				const fd = new FormData();
				fd.append('file', up.files[0]);
				const res = await fetch(`${C.api}orders/${up.dataset.fileUp}/files`, { method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': C.nonce }, body: fd });
				const d = await res.json().catch(() => ({}));
				if (!res.ok) throw new Error(d.message || 'No se pudo subir el archivo.');
				setOrder(d);
				toast('Archivo agregado al pedido');
			} catch (err) { toast(err.message, 'err'); label.classList.remove('is-busy'); }
			return;
		}
		const cb = e.target.closest('[data-flag]');
		if (!cb) return;
		const kind = cb.dataset.flag;
		cb.disabled = true;
		try {
			const o = await api(`orders/${cb.dataset.id}`, { method: 'POST', body: { [kind]: cb.checked } });
			setOrder(o);
			toast(flagMsg[kind][cb.checked ? 0 : 1]);
		} catch (err) { cb.checked = !cb.checked; toast(err.message, 'err'); } finally { cb.disabled = false; }
	});

	document.addEventListener('change', (e) => {
		if (e.target.name === 'same' && e.target.closest('#bk-g-custform')) $('.bk-g-custship').hidden = e.target.checked;
		const sf = e.target.name === 'carrier' && e.target.closest('#bk-g-shipform');
		if (sf) {
			const loc = isLocal(e.target.value);
			$('[data-ship-number]', sf).hidden = loc;
			$('[data-ship-local]', sf).hidden = !loc;
		}
	});

	document.addEventListener('submit', async (e) => {
		const form = e.target;
		if (form.id === 'bk-g-custform') {
			e.preventDefault();
			const err = $('.bk-g-formerr', form);
			const body = { billing: {}, shipping: {}, same: form.same.checked };
			[...form.elements].forEach((el) => {
				const m = /^(billing|shipping)\.(\w+)$/.exec(el.name || '');
				if (m) body[m[1]][m[2]] = el.value.trim();
			});
			if (form.cedula) body.cedula = form.cedula.value.trim();
			err.hidden = true;
			const bad = !body.billing.first_name ? ['billing.first_name', 'Escribe el nombre de la clienta.']
				: (body.billing.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.billing.email)) ? ['billing.email', 'El correo no es válido.'] : null;
			if (bad) { err.textContent = bad[1]; err.hidden = false; form.elements[bad[0]].focus(); return; }
			await busy(form.querySelector('[type="submit"]'), async () => {
				try {
					const o = await api(`orders/${form.dataset.id}/customer`, { method: 'POST', body });
					setOrder(o);
					toast(o.changed?.length ? 'Datos de la clienta guardados' : 'No había cambios');
					loadOrders();
				} catch (er) { err.textContent = er.message; err.hidden = false; }
			});
			return;
		}
		if (form.id === 'bk-g-onote') {
			e.preventDefault();
			const text = $('#bk-g-notetext').value.trim();
			if (!text) return;
			await busy(form.querySelector('button'), async () => {
				const o = await api(`orders/${form.dataset.id}`, { method: 'POST', body: { note: text, customer_note: $('#bk-g-notecust').checked } });
				setOrder(o);
				toast('Nota añadida');
			});
		}
		if (form.id === 'bk-g-shipform') {
			e.preventDefault();
			const err = $('.bk-g-formerr', form);
			const body = { carrier: form.carrier.value, number: isLocal(form.carrier.value) ? '' : form.number.value.trim(), complete: !!form.complete?.checked };
			err.hidden = true;
			if (!body.carrier || (!isLocal(body.carrier) && body.number.length < 4)) {
				err.textContent = !body.carrier ? 'Elige la transportadora.' : 'Escribe el número de guía.';
				err.hidden = false;
				(!body.carrier ? form.carrier : form.number).focus();
				return;
			}
			await busy(form.querySelector('button[type="submit"]'), async () => {
				const d = await api(`orders/${form.dataset.id}/shipment`, { method: 'POST', body });
				openPreview(previewHtml(d, `<button type="button" class="bk-g-btn is-ghost" data-pv-close>Volver a editar</button>
					<button type="button" class="bk-g-btn" data-pv-focus data-ship-confirm>${C.icons.check} Confirmar y enviar a ${esc(d.to)}</button>`));
				fillFrame(d.html);
				pendingShip = { id: form.dataset.id, body };
			});
		}
		if (form.id === 'bk-g-shiptest') {
			e.preventDefault();
			await busy(form.querySelector('button[type="submit"]'), async () => {
				const d = await api('shipment-sample', { method: 'POST', body: { to: form.to.value.trim(), carrier: form.carrier.value } });
				toast(d.sent ? `Correo de prueba enviado a ${d.to}` : 'No se pudo enviar. Revisa la configuración de correo (SMTP).', d.sent ? 'ok' : 'err');
			});
		}
		if (form.id === 'bk-g-sf') {
			e.preventDefault();
			await busy(form.querySelector('button'), async () => {
				await api('settings', { method: 'POST', body: Object.fromEntries(new FormData(form).entries()) });
				toast('Campos guardados');
				viewSettings();
			});
		}
	});

	// API para gestion-product.js (editor de productos).
	window.bkGApp = { C, api, esc, $, $$, toast, busy, main, route, seq: () => viewSeq, openPreview, closePreview, previewHtml, fillFrame, getCached, fetchFresh, forget, showOrder, closeDrawer: () => { if (!drawer.hidden) closeDrawer(); }, pager, qs };
	route();
})();

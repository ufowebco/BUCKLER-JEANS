<?php
/**
 * Velocidad de las páginas limpias: optimización del HTML final (document.php lo tiene completo en un búfer).
 *
 * 1. Quita los snippets antiguos del tema/snippets que solo servían al diseño de Divi (grilla AJAX, flechas,
 *    filtros Themify, video de la galería anterior, etiquetas YayPricing, botones +/−, slider de iconos, botón de
 *    WhatsApp por clase) y, sobre todo, el que ocultaba la página entera (opacity 0) hasta cargar todo.
 *    Siguen activos en wp-admin y en cualquier página que no pinte buckler-core. Lista: bk_legacy_snippets.
 * 2. Quita el "jQuery diferido" de Divi (stub jqueryParams): en estas páginas jQuery carga normal.
 * 3. Quita scripts externos de pasarelas (Rapyd, Bold) y select2 fuera de carrito/pago/cuenta.
 * 4. Retrasa analítica y publicidad (Google Tag Manager, gtag, píxeles, AdsAgent…) hasta la primera interacción
 *    (mover el mouse, tocar, desplazar o una tecla). Conservan su orden. Filtro bk_delay_patterns; se desactiva
 *    con bk_config( 'delay_trackers' ) = false.
 *
 * @package BucklerCore
 */

defined( 'ABSPATH' ) || exit;

/**
 * Firmas de los snippets antiguos (texto que aparece dentro del <script> en línea).
 *
 * @return string[]
 */
function bk_legacy_snippets() {
	return (array) apply_filters(
		'bk_legacy_snippets',
		array(
			"document.documentElement.style.opacity = '0'", // Ocultaba la página hasta el evento load.
			'function cargarGrillaAjax(',                    // Paginación AJAX de la grilla de Divi.
			".woo-prev, .woo-next",                          // Flechas de la galería anterior.
			'wpf_ajax_success',                              // Themify Product Filter.
			'function autoPlayVideoGaleria(',                // Video de la galería de BodyCommerce.
			'function agregarEtiquetasDescuento(',           // Etiquetas de descuento sobre la grilla de Divi.
			"$('.quantity').prepend('<span class=\"minus\">", // Botones +/− (los del carrito son de buckler-core).
			'.listoiconosslider',                            // Slider de iconos de Divi.
			"$('.botonproducto').attr('href'",               // Botón de WhatsApp de la ficha anterior.
		)
	);
}

/**
 * Patrones de scripts que se retrasan hasta la primera interacción (src externo o texto en línea).
 *
 * @return string[] Expresiones regulares.
 */
function bk_delay_patterns() {
	return (array) apply_filters(
		'bk_delay_patterns',
		array(
			'#googletagmanager\.com#',
			'#gtm\.start#',
			'#\bgtag\(#',
			'#connect\.facebook\.net|\bfbq\(#',
			'#/plugins/(facebook-for-woocommerce|official-facebook-pixel|google-listings-and-ads)/#',
			'#woocommerce-analytics|wcAnalytics#',
			'#adsagent|frontendInjection\.js#',
			'#analytics\.tiktok\.com|\bttq\.#',
			'#clarity\.ms|hotjar\.com#',
		)
	);
}

/**
 * Optimiza el HTML de una página de buckler-core.
 *
 * @param string $html  Documento.
 * @param string $route Ruta (home, shop, product…).
 * @return string
 */
function bk_pages_optimize_html( $html, $route ) {
	if ( ! $html || ! $route ) {
		return $html;
	}
	$legacy   = bk_legacy_snippets();
	$delay    = false !== bk_config( 'delay_trackers' ) && ! in_array( $route, array( 'checkout' ), true ) ? bk_delay_patterns() : array();
	$forms    = in_array( $route, array( 'cart', 'checkout', 'account' ), true );
	$delayed  = 0;
	$html     = preg_replace_callback(
		'#<script\b([^>]*)>(.*?)</script>#is',
		static function ( $m ) use ( $legacy, $delay, $forms, $route, &$delayed ) {
			$attrs = $m[1];
			$body  = $m[2];
			$src   = preg_match( '#\ssrc=(["\'])([^"\']+)\1#i', $attrs, $s ) ? $s[2] : '';
			// Datos (JSON-LD, reglas de precarga, plantillas): no se tocan.
			if ( preg_match( '#type=(["\'])(application/(ld\+)?json|speculationrules|text/template|text/html)\1#i', $attrs ) ) {
				return $m[0];
			}
			if ( '' === $src ) {
				foreach ( $legacy as $sig ) {
					if ( false !== strpos( $body, $sig ) ) {
						return '';
					}
				}
				// jQuery diferido de Divi (stub + reproducción tras cargar jQuery).
				if ( 0 === strpos( ltrim( $body ), 'let jqueryParams=[]' ) || 0 === strpos( ltrim( $body ), 'jqueryParams.length&&' ) ) {
					return '';
				}
			} elseif ( 'checkout' !== $route && preg_match( '#checkouttoolkit\.rapyd\.net|checkout\.bold\.co|/plugins/(bold-pagos-en-linea|rapyd-payments-plugin-for-woocommerce)/#', $src ) ) {
				return '';
			} elseif ( ! $forms && preg_match( '#/select2/|/selectWoo/#', $src ) ) {
				return '';
			}
			foreach ( $delay as $re ) {
				if ( preg_match( $re, $src ? $src : $body ) ) {
					++$delayed;
					$attrs = preg_replace( '#\stype=(["\'])[^"\']*\1#i', '', $attrs );
					if ( $src ) {
						$attrs = preg_replace( '#\ssrc=(["\'])([^"\']+)\1#i', ' data-bk-src="$2"', $attrs );
					}
					return '<script type="text/bk-delay"' . $attrs . '>' . $body . '</script>';
				}
			}
			return $m[0];
		},
		$html
	);
	$html = bk_strip_element( (string) $html, '#<div\b[^>]*\bclass=(["\'])pswp\1[^>]*>#i' ); // Visor PhotoSwipe (franja bajo el footer).
	$html = bk_pages_maybe_drop_jquery( (string) $html, $route );
	if ( $delayed ) {
		$html = str_replace( '</body>', bk_delay_loader() . "\n</body>", (string) $html );
	}
	return (string) $html;
}

/**
 * Quita jQuery (≈100 KB) en inicio, tienda, FAQ, políticas y 404 cuando ningún script que queda lo usa:
 * todos los externos son de una lista conocida sin jQuery y ningún script en línea lo menciona.
 *
 * @param string $html  Documento ya optimizado.
 * @param string $route Ruta.
 * @return string
 */
function bk_pages_maybe_drop_jquery( $html, $route ) {
	if ( ! in_array( $route, (array) apply_filters( 'bk_nojquery_routes', array( 'home', 'shop', 'faq', 'policy', '404' ) ), true ) ) {
		return $html;
	}
	$vanilla = (string) apply_filters( 'bk_vanilla_scripts', '#/plugins/buckler-core/|/sourcebuster/|order-attribution|wp-emoji|/js/dist/(hooks|i18n)|googletagmanager\.com|frontendInjection\.js|/jquery/jquery(-migrate)?(\.min)?\.js#' );
	preg_match_all( '#<script\b([^>]*)>(.*?)</script>#is', $html, $all, PREG_SET_ORDER );
	foreach ( $all as $m ) {
		if ( preg_match( '#type=(["\'])(application/(ld\+)?json|speculationrules)\1#i', $m[1] ) || false !== strpos( $m[1], 'id="bk-delay"' ) ) {
			continue;
		}
		$src = preg_match( '#\s(?:data-bk-)?src=(["\'])([^"\']+)\1#i', $m[1], $s ) ? $s[2] : '';
		if ( $src ? ! preg_match( $vanilla, $src ) : preg_match( '#jQuery|\$\(|\$\.#', $m[2] ) ) {
			return $html; // Algo puede necesitar jQuery: se deja.
		}
	}
	return (string) preg_replace( '#<script\b[^>]*src=(["\'])[^"\']*/jquery/jquery(-migrate)?(\.min)?\.js[^"\']*\1[^>]*></script>\s*#i', '', $html );
}

/**
 * Cargador de los scripts retrasados: en la primera interacción los ejecuta en su orden original.
 *
 * @return string
 */
function bk_delay_loader() {
	return '<script id="bk-delay">(()=>{const E=["pointerdown","pointermove","keydown","touchstart","scroll","wheel"];let go=0;const run=async()=>{if(go)return;go=1;E.forEach(e=>removeEventListener(e,run,{passive:!0}));for(const o of document.querySelectorAll(\'script[type="text/bk-delay"]\')){await new Promise(r=>{const n=document.createElement("script");for(const a of o.attributes)if(a.name!=="type"&&a.name!=="data-bk-src")n.setAttribute(a.name,a.value);if(o.dataset.bkSrc){n.src=o.dataset.bkSrc;n.onload=n.onerror=r}else{n.text=o.textContent}o.replaceWith(n);if(!o.dataset.bkSrc)r()})}};E.forEach(e=>addEventListener(e,run,{passive:!0}))})();</script>';
}

add_action( 'wp_enqueue_scripts', 'bk_pages_bundle_css', 10005 );

/**
 * Une los CSS de buckler-core de la página en un solo archivo (uploads/bk-cache/), para que el celular haga una
 * petición que bloquea el pintado en vez de cinco o seis. El nombre lleva un hash de los archivos y sus fechas,
 * así cada versión nueva genera su propio paquete. Si uploads no admite escritura, se dejan los archivos sueltos.
 */
function bk_pages_bundle_css() {
	if ( ! bk_pages_route() || ! apply_filters( 'bk_bundle_css', true ) ) {
		return;
	}
	$styles = wp_styles();
	$base   = BK_URL . 'assets/css/';
	$parts  = array();
	foreach ( (array) $styles->queue as $handle ) {
		$src = isset( $styles->registered[ $handle ] ) ? (string) $styles->registered[ $handle ]->src : '';
		if ( 0 !== strpos( $src, $base ) || ! empty( $styles->registered[ $handle ]->extra['after'] ) ) {
			continue;
		}
		$file = BK_DIR . 'assets/css/' . basename( (string) wp_parse_url( $src, PHP_URL_PATH ) );
		if ( is_readable( $file ) ) {
			$parts[ $handle ] = $file;
		}
	}
	// Orden de dependencias: core primero, después el resto en el orden de la cola.
	if ( count( $parts ) < 2 ) {
		return;
	}
	$sig = '';
	foreach ( $parts as $h => $f ) {
		$sig .= $h . filemtime( $f ) . filesize( $f );
	}
	$name = 'bk-' . substr( md5( $sig . BK_VERSION ), 0, 12 ) . '.css';
	$up   = wp_upload_dir( null, false );
	$dir  = trailingslashit( $up['basedir'] ) . 'bk-cache';
	$path = $dir . '/' . $name;
	if ( ! is_file( $path ) ) {
		if ( ! wp_mkdir_p( $dir ) || ! wp_is_writable( $dir ) ) {
			return;
		}
		$css = '';
		foreach ( $parts as $h => $f ) {
			// Rutas relativas (fuentes) → absolutas, porque el paquete vive en otra carpeta.
			$css .= "/* {$h} */\n" . preg_replace( '#url\(\s*([\'"]?)\.\./#', 'url($1' . BK_URL . 'assets/', (string) file_get_contents( $f ) ) . "\n"; // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		$tmp = $path . '.' . wp_generate_password( 6, false ) . '.tmp';
		if ( false === file_put_contents( $tmp, $css ) || ! rename( $tmp, $path ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			@unlink( $tmp ); // phpcs:ignore
			return;
		}
	}
	foreach ( array_keys( $parts ) as $h ) {
		wp_dequeue_style( $h );
	}
	wp_enqueue_style( 'bk-bundle', trailingslashit( $up['baseurl'] ) . 'bk-cache/' . $name, array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- el hash va en el nombre.
}

/**
 * Quita un elemento <div> completo (con sus <div> internos) a partir de su etiqueta de apertura.
 *
 * @param string $html  Documento.
 * @param string $open  Expresión regular de la etiqueta de apertura.
 * @return string
 */
function bk_strip_element( $html, $open ) {
	while ( preg_match( $open, $html, $m, PREG_OFFSET_CAPTURE ) ) {
		$start = $m[0][1];
		$pos   = $start + strlen( $m[0][0] );
		$depth = 1;
		while ( $depth > 0 && preg_match( '#<(/?)div\b[^>]*>#i', $html, $t, PREG_OFFSET_CAPTURE, $pos ) ) {
			$depth += '/' === $t[1][0] ? -1 : 1;
			$pos    = $t[0][1] + strlen( $t[0][0] );
		}
		if ( $depth > 0 ) {
			break; // HTML mal formado: no se toca.
		}
		$html = substr( $html, 0, $start ) . substr( $html, $pos );
	}
	return $html;
}

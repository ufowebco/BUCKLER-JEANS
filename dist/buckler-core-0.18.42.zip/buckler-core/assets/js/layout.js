/**
 * Header [bk_header]: anuncios, menú de la tienda, buscador móvil, menú lateral y contador del carrito.
 * Sin dependencias. jQuery solo se usa (si existe) para escuchar los eventos de carrito de WooCommerce.
 */
(() => {
	'use strict';

	/* --- Seguimiento para Google Tag Manager (dataLayer) --------------------------------------
	 * Eventos propios con prefijo bk_ (no chocan con los de otros plugins). GTM los recibe aunque cargue
	 * después (cola de dataLayer). Lista completa en Gestión de tienda → SEO y ADS. */
	window.bkTrack = window.bkTrack || ((event, data = {}) => {
		window.dataLayer = window.dataLayer || [];
		if (data.ecommerce) window.dataLayer.push({ ecommerce: null });
		window.dataLayer.push({ event, ...data });
	});
	const txt = (el) => (el?.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 100);
	document.addEventListener('click', (e) => {
		const a = e.target.closest('a, button');
		if (!a) return;
		const href = a.getAttribute('href') || '';
		if (/wa\.me|whatsapp\.com/.test(href)) window.bkTrack('bk_whatsapp_click', { link_url: href, link_text: txt(a) });
		else if (a.matches('.bk-card__link')) window.bkTrack('bk_select_item', { item_name: txt(a.closest('.bk-card')?.querySelector('.bk-card__title')), link_url: href });
		else if (a.matches('.bk-pdp__guide')) window.bkTrack('bk_size_guide_open');
		else if (a.matches('.bk-size')) window.bkTrack('bk_size_select', { size: txt(a) });
		else if (a.matches('.bk-pdp__twin')) window.bkTrack('bk_other_line_click', { link_url: href });
		else if (a.closest('.bk-promo, .bk-mega__card.is-review') || /g\.page\/r\/|google\.com\/maps.*review/.test(href)) window.bkTrack('bk_review_click', { link_url: href });
		else if (a.matches('.bk-sc__btn--primary, .checkout-button, a[href*="finalizar-compra"], a[href*="/checkout"]')) window.bkTrack('bk_begin_checkout', { link_url: href });
		else if (a.closest('.bk-hero')) window.bkTrack('bk_banner_click', { link_url: href, banner: 'hero' });
		else if (a.closest('.bk-lineas')) window.bkTrack('bk_banner_click', { link_url: href, banner: 'lineas' });
	}, { passive: true });
	document.addEventListener('submit', (e) => {
		const f = e.target;
		if (f.matches?.('.bk-search, [role="search"]')) window.bkTrack('bk_search', { search_term: (new FormData(f).get('s') || '').toString().slice(0, 100) });
	});

	const header = document.querySelector('[data-bk-header]');
	if (!header) return;

	const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
	const desktop = window.matchMedia('(min-width: 1100px)');
	const root = document.documentElement;

	/* --- Barra de anuncios: carrusel de --per anuncios (3 escritorio / 1 celular) -----
	 * Avanza de a uno cada 4 s; se detiene con el cursor o el foco encima y no se mueve si la persona
	 * pidió reducir el movimiento. Los clones del final (aria-hidden) permiten el bucle sin salto visible. */
	const vp = header.querySelector('[data-bk-announce]');
	if (vp) {
		const list = vp.querySelector('.bk-announce__list');
		const originals = [...list.children];
		let per = 1;
		let items = [];
		let i = 0;
		let timer = 0;
		let hold = false;
		const visible = () => originals.filter((el) => getComputedStyle(el).display !== 'none');
		const build = () => {
			list.querySelectorAll('.is-clone').forEach((c) => c.remove());
			per = parseInt(getComputedStyle(vp).getPropertyValue('--per'), 10) || 1;
			items = visible();
			items.slice(0, per).forEach((el) => {
				const c = el.cloneNode(true);
				c.classList.add('is-clone');
				c.setAttribute('aria-hidden', 'true');
				c.querySelectorAll('a').forEach((a) => a.setAttribute('tabindex', '-1'));
				list.appendChild(c);
			});
			i = 0;
			move(false);
		};
		const move = (anim) => {
			list.style.transition = anim ? '' : 'none';
			// La lista mide lo mismo que el visor: cada paso es 100 / per % de su ancho.
			list.style.transform = `translateX(${-(100 / per) * i}%)`;
		};
		const step = () => {
			if (hold || document.hidden || items.length <= per) return;
			i += 1;
			move(true);
			if (i === items.length) {
				setTimeout(() => { i = 0; move(false); }, 650);
			}
		};
		const run = () => {
			clearInterval(timer);
			if (!reduceMotion.matches) timer = setInterval(step, 4000);
		};
		['mouseenter', 'focusin'].forEach((ev) => vp.addEventListener(ev, () => { hold = true; }));
		['mouseleave', 'focusout'].forEach((ev) => vp.addEventListener(ev, () => { hold = false; }));
		let rt = 0;
		window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(build, 150); }, { passive: true });
		build();
		// Empieza a rotar con la primera interacción (la página carga quieta).
		const EV = ['pointermove', 'pointerdown', 'keydown', 'scroll', 'touchstart', 'wheel'];
		const arm = () => { EV.forEach((e) => window.removeEventListener(e, arm)); run(); };
		EV.forEach((e) => window.addEventListener(e, arm, { passive: true }));
	}

	/* --- Altura del header para elementos pegajosos (barra de filtros, etc.) --- */
	const sticky = header.closest('.et-l--header') || header;
	const setH = () => root.style.setProperty('--bk-header-h', `${Math.round(sticky.getBoundingClientRect().height)}px`);
	if ('ResizeObserver' in window) new ResizeObserver(setH).observe(sticky);
	setH();

	/* --- Sombra al hacer scroll ---------------------------------------------- */
	const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
	window.addEventListener('scroll', onScroll, { passive: true });
	onScroll();

	/* --- Página actual en el menú ------------------------------------------- */
	header.querySelectorAll('.bk-nav__link[href], .bk-drawer__link[href]').forEach((a) => {
		const u = new URL(a.href);
		if (u.pathname === location.pathname && u.search === location.search) a.setAttribute('aria-current', 'page');
	});

	/* --- Menú desplegable de la tienda (clic, teclado y hover con retardo) ---- */
	header.querySelectorAll('.has-mega').forEach((li) => {
		const btn = li.querySelector('button[aria-controls]');
		const panel = document.getElementById(btn.getAttribute('aria-controls'));
		if (!panel) return;
		let closeTimer = 0;
		let openTimer = 0;

		const set = (open) => {
			btn.setAttribute('aria-expanded', String(open));
			panel.hidden = !open;
		};
		const isOpen = () => btn.getAttribute('aria-expanded') === 'true';

		btn.addEventListener('click', () => set(!isOpen()));
		li.addEventListener('mouseenter', () => {
			if (!desktop.matches) return;
			clearTimeout(closeTimer);
			openTimer = setTimeout(() => set(true), 120);
		});
		li.addEventListener('mouseleave', () => {
			clearTimeout(openTimer);
			closeTimer = setTimeout(() => set(false), 220);
		});
		li.addEventListener('keydown', (e) => {
			if (e.key === 'Escape' && isOpen()) {
				set(false);
				btn.focus();
			}
		});
		li.addEventListener('focusout', (e) => {
			if (!li.contains(e.relatedTarget)) set(false);
		});
		document.addEventListener('click', (e) => {
			if (isOpen() && !li.contains(e.target)) set(false);
		});
	});

	/* --- Buscador móvil ------------------------------------------------------ */
	const searchBtn = header.querySelector('.bk-search-toggle');
	if (searchBtn) {
		const box = document.getElementById(searchBtn.getAttribute('aria-controls'));
		searchBtn.addEventListener('click', () => {
			const open = searchBtn.getAttribute('aria-expanded') !== 'true';
			searchBtn.setAttribute('aria-expanded', String(open));
			box.hidden = !open;
			if (open) box.querySelector('input[type="search"]')?.focus();
		});
	}

	/* --- Buscador en vivo: muestra productos mientras se escribe (combobox ARIA) --- */
	const S = window.bkSearch;
	if (S && S.index) {
		let data = null;
		let loading = null;
		const norm = (v) => String(v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
		const load = () => {
			if (!loading) {
				loading = fetch(S.index, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
					.then((r) => (r.ok ? r.json() : []))
					.then((d) => { data = Array.isArray(d) ? d : []; return data; })
					.catch(() => { loading = null; return []; });
			}
			return loading;
		};
		const esc = (v) => String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

		document.querySelectorAll('.bk-search').forEach((form, f) => {
			const input = form.querySelector('input[type="search"]');
			if (!input) return;
			const id = `bk-sr-${f}`;
			const box = document.createElement('div');
			box.className = 'bk-sr';
			box.id = id;
			box.setAttribute('role', 'listbox');
			box.setAttribute('aria-label', input.placeholder || 'Productos');
			box.hidden = true;
			const live = document.createElement('div');
			live.className = 'bk-sr-only';
			live.setAttribute('role', 'status');
			form.append(box, live);
			input.setAttribute('role', 'combobox');
			input.setAttribute('aria-autocomplete', 'list');
			input.setAttribute('aria-expanded', 'false');
			input.setAttribute('aria-controls', id);
			let active = -1;
			let timer = 0;

			const options = () => [...box.querySelectorAll('[role="option"]')];
			const close = () => {
				box.hidden = true;
				input.setAttribute('aria-expanded', 'false');
				input.removeAttribute('aria-activedescendant');
				active = -1;
			};
			const mark = (n) => {
				const o = options();
				if (!o.length) return;
				active = (n + o.length) % o.length;
				o.forEach((el, i) => el.setAttribute('aria-selected', String(i === active)));
				input.setAttribute('aria-activedescendant', o[active].id);
				o[active].scrollIntoView({ block: 'nearest' });
			};
			const allUrl = (q) => `${S.all}${S.all.includes('?') ? '&' : '?'}s=${encodeURIComponent(q)}`;
			const render = (q) => {
				const words = norm(q).split(' ').filter(Boolean);
				const hits = (data || []).filter((it) => words.every((w) => it.t.includes(w)));
				const first = norm(words[0] || '');
				hits.sort((a, b) => (norm(b.n).startsWith(first) ? 1 : 0) - (norm(a.n).startsWith(first) ? 1 : 0));
				const top = hits.slice(0, 6);
				const t = S.i18n || {};
				let html = top.map((it, i) => `<a role="option" id="${id}-${i}" aria-selected="false" class="bk-sr__item" href="${esc(it.u)}" tabindex="-1">`
					+ (it.i ? `<img src="${esc(it.i)}" alt="" width="48" height="64" decoding="async">` : '<span class="bk-sr__ph"></span>')
					+ `<span class="bk-sr__txt"><span class="bk-sr__name">${esc(it.n)}</span>${it.l ? `<span class="bk-sr__line">${esc(it.l)}</span>` : ''}</span>`
					+ `<span class="bk-sr__price">${it.o ? `<del>${esc(it.o)}</del> ` : ''}${esc(it.p)}</span></a>`).join('');
				if (!top.length) html = `<p class="bk-sr__none">${esc(t.none || 'Sin resultados')}</p>`;
				html += `<a role="option" id="${id}-all" aria-selected="false" class="bk-sr__all" href="${esc(allUrl(q))}" tabindex="-1">${esc(t.seeAll || 'Ver todos')}${hits.length ? ` (${hits.length})` : ''}</a>`;
				box.innerHTML = html;
				box.hidden = false;
				input.setAttribute('aria-expanded', 'true');
				input.removeAttribute('aria-activedescendant');
				active = -1;
				live.textContent = hits.length === 1 ? (t.one || '1') : (hits.length ? (t.results || '%d').replace('%d', hits.length) : (t.none || ''));
			};
			const run = () => {
				const q = input.value.trim();
				if (q.length < 2) { close(); return; }
				if (data) render(q);
				else {
					box.innerHTML = `<p class="bk-sr__none">${esc((S.i18n && S.i18n.loading) || '…')}</p>`;
					box.hidden = false;
					load().then(() => { if (input.value.trim() === q) render(q); });
				}
			};
			input.addEventListener('focus', () => { load(); if (input.value.trim().length >= 2 && box.hidden) run(); }, { passive: true });
			input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 90); });
			input.addEventListener('keydown', (e) => {
				if (e.key === 'ArrowDown') { e.preventDefault(); if (box.hidden) run(); else mark(active + 1); }
				else if (e.key === 'ArrowUp') { e.preventDefault(); if (!box.hidden) mark(active - 1); }
				else if (e.key === 'Escape' && !box.hidden) { e.preventDefault(); e.stopPropagation(); close(); }
				else if (e.key === 'Enter' && active > -1 && !box.hidden) { e.preventDefault(); window.location.href = options()[active].href; }
			});
			box.addEventListener('mousedown', (e) => e.preventDefault()); // El clic no quita el foco antes de navegar.
			form.addEventListener('focusout', (e) => { if (!form.contains(e.relatedTarget)) close(); });
		});
	}

	/* --- Menú lateral (diálogo modal accesible) ------------------------------ */
	const burger = header.querySelector('.bk-burger');
	const drawer = burger && document.getElementById(burger.getAttribute('aria-controls'));
	if (drawer) {
		// Se mueve al <body> para que el position:fixed no dependa del header sticky.
		document.body.appendChild(drawer);
		const panel = drawer.querySelector('.bk-drawer__panel');
		const focusables = () => [...panel.querySelectorAll('a[href], button, summary, input')].filter((el) => el.offsetParent !== null);

		const open = () => {
			drawer.hidden = false;
			burger.setAttribute('aria-expanded', 'true');
			root.classList.add('bk-drawer-open');
			focusables()[0]?.focus();
		};
		const close = () => {
			drawer.hidden = true;
			burger.setAttribute('aria-expanded', 'false');
			root.classList.remove('bk-drawer-open');
			burger.focus();
		};

		burger.addEventListener('click', open);
		drawer.querySelector('.bk-drawer__close').addEventListener('click', close);
		drawer.addEventListener('click', (e) => { if (e.target === drawer) close(); });
		drawer.addEventListener('keydown', (e) => {
			if (e.key === 'Escape') {
				close();
				return;
			}
			if (e.key !== 'Tab') return;
			const f = focusables();
			const first = f[0];
			const last = f[f.length - 1];
			if (e.shiftKey && document.activeElement === first) { last.focus(); e.preventDefault(); }
			else if (!e.shiftKey && document.activeElement === last) { first.focus(); e.preventDefault(); }
		});
		desktop.addEventListener('change', (e) => { if (e.matches && !drawer.hidden) close(); });
		window.addEventListener('pageshow', () => { if (!drawer.hidden) close(); });
	}

	/* --- Contador del carrito (Store API; solo si hay carrito) ------------------ */
	const countEls = document.querySelectorAll('[data-bk-cart-count]');
	const cartLink = header.querySelector('[data-bk-cart]');
	const label = cartLink?.querySelector('.bk-sr-only');
	const render = (n) => {
		countEls.forEach((el) => {
			el.textContent = n > 99 ? '99+' : String(n);
			el.hidden = n < 1;
		});
		if (label) label.textContent = n > 0 ? `Carrito, ${n} ${n === 1 ? 'producto' : 'productos'}` : 'Carrito vacío';
	};
	const hasCartCookie = () => /(?:^|;\s*)woocommerce_items_in_cart=1/.test(document.cookie);
	const refresh = (bump) => {
		if (!hasCartCookie()) { render(0); return; }
		// Si el carrito flotante acaba de actualizar el contador, no se vuelve a pedir el carrito (el servidor tarda ~3 s).
		if (bump && Date.now() - (window.bkCartSynced || 0) < 2000) {
			if (cartLink) { cartLink.classList.remove('is-bump'); void cartLink.offsetWidth; cartLink.classList.add('is-bump'); }
			return;
		}
		fetch((window.bkCore && window.bkCore.cartApi) || '/wp-json/wc/store/v1/cart', { credentials: 'same-origin', headers: { Accept: 'application/json' } })
			.then((r) => {
				// El nonce de la Store API se comparte con el carrito flotante: así "Añadir" no espera otra petición.
				const n = r.headers.get('Nonce');
				if (n) window.bkStoreNonce = n;
				return r.ok ? r.json() : null;
			})
			.then((cart) => {
				if (!cart) return;
				window.bkCartSnapshot?.(cart); // El carrito flotante abre al instante con esta lectura.
				render(cart.items_count || 0);
				if (bump && cartLink) {
					cartLink.classList.remove('is-bump');
					void cartLink.offsetWidth;
					cartLink.classList.add('is-bump');
				}
			})
			.catch(() => {});
	};
	refresh(false);
	window.addEventListener('pageshow', (e) => { if (e.persisted) refresh(false); });
	if (window.jQuery) {
		window.jQuery(document.body).on('added_to_cart removed_from_cart updated_cart_totals wc_fragments_refreshed', () => refresh(true));
	}
	// API pública para el carrito flotante (fase 3).
	window.bkCart = { refresh, set: render };
})();

<?php
/**
 * Ajustes de textos de WooCommerce.
 *
 * SKU → REF (reemplaza el snippet "PALABRA - SKU POR REF").
 * Mejoras sobre el snippet original:
 *  - Usa `gettext_woocommerce` (filtro por dominio, WP 5.5+): no se ejecuta en los miles de textos de
 *    otros plugins, solo en los de WooCommerce.
 *  - Cubre todas las variantes ("SKU", "SKU:", "SKU %s", "Parent SKU", "Buscar por SKU"…), también las
 *    ya traducidas al español, y los plurales (`ngettext_woocommerce`).
 *  - No toca datos: el campo sigue siendo el SKU de WooCommerce (feeds de Meta/Google, schema y la
 *    API siguen usando "sku").
 *
 * Limitación conocida (igual que el snippet): los textos del editor de productos que WooCommerce pinta
 * con JavaScript (React) no pasan por gettext de PHP.
 *
 * @package BucklerCore
 */

defined( 'ABSPATH' ) || exit;

if ( bk_on( 'sku_ref' ) ) {
	add_filter( 'gettext_woocommerce', 'bk_sku_to_ref', 10, 1 );
	add_filter( 'ngettext_woocommerce', 'bk_sku_to_ref', 10, 1 );
}

/**
 * Cambia la palabra SKU por REF en un texto ya traducido.
 *
 * @param string $translation Texto traducido.
 * @return string
 */
function bk_sku_to_ref( $translation ) {
	if ( false === strpos( $translation, 'SKU' ) ) {
		return $translation; // Salida rápida: la gran mayoría de textos no contiene "SKU".
	}
	return preg_replace( '/\bSKU(s?)\b/', 'REF$1', $translation );
}

/**
 * Departamentos de Colombia: "San Andrés y Providencia" → "San Andrés" (no hay envíos a Providencia;
 * decisión del cliente 2026-10-15). Se cambia solo el nombre: el código CO-SAP de los pedidos no cambia.
 * Nombre configurable con el filtro bk_state_names.
 */
add_filter(
	'woocommerce_states',
	static function ( $states ) {
		$names = (array) apply_filters( 'bk_state_names', array( 'CO' => array( 'CO-SAP' => 'San Andrés' ) ) );
		foreach ( $names as $country => $map ) {
			foreach ( (array) $map as $code => $name ) {
				if ( isset( $states[ $country ][ $code ] ) ) {
					$states[ $country ][ $code ] = $name;
				}
			}
		}
		return $states;
	},
	99
);

/**
 * Checkout: el correo va de primero (lo primero que se pide es lo que permite recuperar la compra)
 * y la casilla de autorización de carritos abandonados justo debajo. Prioridad 20: después de otros
 * plugins/snippets que reordenan campos. address-i18n.js de Woo reordena por data-priority, así que se
 * mantiene también al cambiar de país. Desactivar: add_filter( 'bk_checkout_email_first', '__return_false' ).
 */
add_filter(
	'woocommerce_checkout_fields',
	static function ( $fields ) {
		if ( ! isset( $fields['billing']['billing_email'] ) || ! apply_filters( 'bk_checkout_email_first', true ) ) {
			return $fields;
		}
		$fields['billing']['billing_email']['priority'] = 1;
		$fields['billing']['billing_email']['class']    = array_values( array_diff( (array) ( $fields['billing']['billing_email']['class'] ?? array() ), array( 'form-row-first', 'form-row-last' ) ) );
		if ( ! in_array( 'form-row-wide', $fields['billing']['billing_email']['class'], true ) ) {
			$fields['billing']['billing_email']['class'][] = 'form-row-wide';
		}
		if ( isset( $fields['billing']['bk_ac_consent'] ) ) {
			$fields['billing']['bk_ac_consent']['priority'] = 2;
		}
		return $fields;
	},
	20
);

/**
 * Checkout: campos de dirección para Colombia. La ciudad se ocultó en 0.17.6 y volvió en 0.18.13 (obligatoria: Addi la
 * exige para aprobar el crédito y las transportadoras la necesitan). El código postal se ocultó en 0.17.6 y volvió en
 * 0.18.16 como opcional (decisión del cliente 2026-10-20). Lo que se oculte se quita del formulario (facturación y envío)
 * y del idioma de direcciones de Colombia, para que el script de Woo no lo vuelva a mostrar ni exigir.
 * Ocultar de nuevo el código postal: add_filter( 'bk_checkout_hidden_fields', fn() => array( 'postcode' ) ).
 */
function bk_checkout_hidden_fields() {
	return (array) apply_filters( 'bk_checkout_hidden_fields', array() );
}

add_filter(
	'woocommerce_checkout_fields',
	static function ( $fields ) {
		foreach ( bk_checkout_hidden_fields() as $f ) {
			unset( $fields['billing'][ 'billing_' . $f ], $fields['shipping'][ 'shipping_' . $f ] );
		}
		// Código postal visible pero opcional.
		foreach ( array( 'billing', 'shipping' ) as $g ) {
			if ( isset( $fields[ $g ][ $g . '_postcode' ] ) ) {
				$fields[ $g ][ $g . '_postcode' ]['required'] = false;
			}
		}
		return $fields;
	},
	30
);

add_filter(
	'woocommerce_get_country_locale',
	static function ( $locale ) {
		foreach ( bk_checkout_hidden_fields() as $f ) {
			$locale['CO'][ $f ] = array_merge( (array) ( $locale['CO'][ $f ] ?? array() ), array( 'required' => false, 'hidden' => true ) );
		}
		// Ciudad visible y obligatoria, con el nombre que se usa en Colombia (Woo en español dice "Población").
		if ( ! in_array( 'city', bk_checkout_hidden_fields(), true ) ) {
			$locale['CO']['city'] = array_merge( (array) ( $locale['CO']['city'] ?? array() ), array( 'label' => __( 'Ciudad o municipio', 'buckler-core' ), 'required' => true, 'hidden' => false ) );
		}
		if ( ! in_array( 'postcode', bk_checkout_hidden_fields(), true ) ) {
			$locale['CO']['postcode'] = array_merge( (array) ( $locale['CO']['postcode'] ?? array() ), array( 'label' => __( 'Código postal', 'buckler-core' ), 'required' => false, 'hidden' => false ) );
		}
		return $locale;
	},
	30
);

/**
 * Checkout: celular obligatorio (decisión del cliente 2026-10-20). Se fuerza aunque en WooCommerce el campo esté como
 * "Opcional" u "Oculto" (Personalizar → WooCommerce → Finalizar compra), y se valida que tenga 10 dígitos (acepta
 * espacios, guiones y el prefijo +57). Desactivar: add_filter( 'bk_checkout_phone_required', '__return_false' ).
 */
function bk_checkout_phone_required() {
	return (bool) apply_filters( 'bk_checkout_phone_required', true );
}

add_filter(
	'woocommerce_checkout_fields',
	static function ( $fields ) {
		if ( ! bk_checkout_phone_required() ) {
			return $fields;
		}
		$phone = $fields['billing']['billing_phone'] ?? array();
		$fields['billing']['billing_phone'] = array_merge(
			array(
				'type'         => 'tel',
				'class'        => array( 'form-row-wide' ),
				'validate'     => array( 'phone' ),
				'autocomplete' => 'tel',
				'priority'     => 100,
			),
			(array) $phone,
			array(
				'label'             => __( 'Celular', 'buckler-core' ),
				'required'          => true,
				'placeholder'       => __( 'Ej.: 300 123 4567', 'buckler-core' ),
				'custom_attributes' => array_merge( (array) ( $phone['custom_attributes'] ?? array() ), array( 'inputmode' => 'tel' ) ),
			)
		);
		return $fields;
	},
	40
);

// El script de direcciones de Woo (address-i18n.js) vuelve a marcar el teléfono como opcional u oculto al cambiar de
// país o departamento si el idioma de direcciones lo dice así: se corrige también ahí.
add_filter(
	'woocommerce_get_country_locale_default',
	static function ( $locale ) {
		if ( bk_checkout_phone_required() ) {
			$locale['phone'] = array_merge( (array) ( $locale['phone'] ?? array() ), array( 'label' => __( 'Celular', 'buckler-core' ), 'required' => true, 'hidden' => false ) );
		}
		return $locale;
	},
	40
);

add_action(
	'woocommerce_after_checkout_validation',
	static function ( $data, $errors ) {
		if ( ! bk_checkout_phone_required() || $errors->get_error_message( 'billing_phone_required' ) ) {
			return;
		}
		$digits = preg_replace( '/\D+/', '', (string) ( $data['billing_phone'] ?? '' ) );
		if ( 12 === strlen( $digits ) && 0 === strpos( $digits, '57' ) ) {
			$digits = substr( $digits, 2 );
		}
		if ( 10 !== strlen( $digits ) ) {
			$errors->add( 'billing_phone_validation', __( 'Escribe un <strong>celular</strong> de 10 dígitos (por ejemplo 300 123 4567) para avisarte del envío.', 'buckler-core' ), array( 'id' => 'billing_phone' ) );
		}
	},
	10,
	2
);

/*
 * Inventario de pedidos cancelados o fallidos (hallazgo 2026-10-30). Un snippet de producción ("Descontar inventario -
 * pendientes de pago") llama a wc_reduce_stock_levels() al pasar a "Pendiente": descuenta las prendas y marca cada
 * línea (_reduced_stock), pero no pone la marca del pedido (_order_stock_reduced) que WooCommerce revisa antes de
 * devolverlas. Resultado: al cancelarse sin pagar, las prendas no volvían al inventario. Justo antes de que WooCommerce
 * lo revise (prioridad 10) se pone esa marca si alguna línea sigue descontada; wc_increase_stock_levels() borra
 * _reduced_stock al devolver, así que nunca se devuelve dos veces. Filtro bk_restore_stock_fix para apagarlo.
 */
foreach ( array( 'cancelled', 'failed' ) as $bk_st ) {
	add_action(
		'woocommerce_order_status_' . $bk_st,
		static function ( $order_id ) {
			if ( ! apply_filters( 'bk_restore_stock_fix', true ) ) {
				return;
			}
			$o = wc_get_order( $order_id );
			if ( ! $o || $o->get_data_store()->get_stock_reduced( $order_id ) ) {
				return;
			}
			foreach ( $o->get_items() as $item ) {
				if ( (float) $item->get_meta( '_reduced_stock', true ) > 0 ) {
					$o->get_data_store()->set_stock_reduced( $order_id, true );
					return;
				}
			}
		},
		5
	);
}
